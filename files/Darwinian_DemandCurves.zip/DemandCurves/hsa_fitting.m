%% Estimation of HSA Demand Curve
% Program by Sihwan Yang, Kunal Sangani, and David Baqaee

%% Arguments:
% mu_last:          Highest markup of largest firm in the data (required argument)
% delta_cutof:      Consumer surplus ratio of smallest firm in the data
%                   If delta_cutoff <= 1, the program will set delta_cutoff
%                   equal to mu_last.
% rho_min:          Pass-through of largest firm in the data
%                   If rho_min >= 1 or rho_min <= 0, the program will
%                   use the Amiti et al (2018) estimates of pass-through to
%                   calculate all results.
%% Returns:          
% share_composite   The expenditure share function s(p/P)
% rho_composite     The pass-through function rho(p/P)
% mu_composite      The markup function mu(p/P)
% delta_composite   The consumer surplus ratio function delta(p/P)
% AB                The productivity/quality distribution AB required to
%                   match the distribution of sales in the Belgian VAT data.
% p                 The distribution of relative prices p/P required to
%                   match the distribution of sales in the Belgian VAT data.
% NOTE: The share, pass-through, markup, and consumer surplus ratio
% functions are only identified over the range of values in p. The return
% functions extrapolate beyond p by assuming constant pass-through of 1 for
% small firms and rho_min for large firms.

% See "The Darwinian Returns to Scale" (David Baqaee, Emmanuel Farhi, and
% Kunal Sangani) for more detail on these functions.

function [share_composite, rho_composite, mu_composite, delta_composite, AB, p] = hsa_fitting(mu_last, delta_cutoff, rho_min)

addpath('./Functions')

if delta_cutoff < 1
    delta_cutoff = mu_last;
end
if rho_min >= 1 || rho_min <= 0
    rho_min = 1;
end

%% Read Prodcom and VAT data
data_PRODCOM = xlsread('Data/DataFigA2.xlsx','Sheet1');
data_VAT = xlsread('Data/DataFigA2.xlsx','Sheet2');
options = optimset('Display','iter','MaxFunEvals',10000,'TolFun',1E-10);

theta_new = [data_VAT(:,4) ; 1]; % VAT Manufacturing input
lambda_new = [data_VAT(:,3) ; 1]; % VAT Manufacturing input
theta_new_0 = [0 ; data_VAT(:,4)];
lambda_new_0 = [0 ; data_VAT(:,3)];

lambda_50 = [0.13926788 ; data_PRODCOM(:,4)];
lambda_50_1 = [0.13926788 ; data_PRODCOM(:,4) ;1]; % PRODCOM input
theta = data_PRODCOM(:,2);
theta_0 = [0 ; data_PRODCOM(:,2)];
theta_50 = [0.62183176 ; data_PRODCOM(:,2)];
theta_50_1 = [0.62183176 ; data_PRODCOM(:,2) ; 1]; % PRODCOM input
rho = data_PRODCOM(:,5); 
rho_1 = [0.97 ; data_PRODCOM(:,5)];

%% Match parameterized distribution to Prodcom
h = 0.0001; % grid size
n = 1/h; % number of grid
pstep = 10; % grid stepsize to draw graphs
theta_grid = theta_new(1):h:1;
theta_grid_all = 0:h:1;
firstobs = floor(n*theta_grid(1))+1;

data_PRODCOM_input = [theta_50_1, lambda_50_1];
F = @(x,data) x(1)*ones(length(data),1)+x(2)*data(:,1)+x(3)*data(:,1).^x(4)-(x(1)+x(2)+x(3));
[x1,resnorm,~,exitflag,output] = lsqcurvefit(F,[0 1 .2 90],data_PRODCOM_input(:,1),log(data_PRODCOM_input(:,2)));
lambda_grid_temp = exp(F(x1,theta_grid_all'));
lambda_grid_PRODCOM = lambda_grid_temp';
slm_rho = slmengine(theta_0,rho_1,'knots',10,'concavedown','on','maxslope',-0.05);
rho_grid = slmeval(theta_grid_all,slm_rho);

%% Differentiate Sales share (PRODCOM)
lambda_diff_PRODCOM = diff(lambda_grid_PRODCOM)/h;
rho_diff_PRODCOM = lambda_grid_PRODCOM(2:end)./lambda_diff_PRODCOM.*diff(rho_grid)/h + rho_grid(2:end);

%% Record rho from PRODCOM and interpolate
theta_VAT = [floor(theta_50(1)*n) ; floor((theta_50(1)+theta_50(2))/2*n) ; ...,
    floor(theta_50(2:end)*n)];
rho_diff_VAT = [0.97*ones(8,1) ; rho_diff_PRODCOM(theta_VAT)'];

%% Fitting Sales share (VAT Manufacturing)
data_VAT_input = [theta_new , lambda_new];
[x2,resnorm,~,exitflag,output] = lsqcurvefit(F,[0 1 .2 90],data_VAT_input(:,1),log(data_VAT_input(:,2)));
lambda_grid_all_temp = exp(F(x2,theta_grid'));
lambda_grid_all = lambda_grid_all_temp';
slm_rho2 = slmengine(theta_new_0,rho_diff_VAT,'knots',10,'concavedown','on','maxslope',-0.05);
rho_diff_all = slmeval(theta_grid_all,slm_rho2);
rho_diff = rho_diff_all(2:end);

%% Differentiate Sales share (VAT Manufacturing)
% dlog(lambda)/d(theta)=constant from 0 to 0.16
lambda_diff = diff(lambda_grid_all)/h;
lambda_diff2 = 1/h*diff(lambda_diff)./lambda_diff(2:end);
lambda_diff2_all = [lambda_diff2(1)*ones(1,firstobs+1), lambda_diff2];
lambda_cumul1 = ones(1,firstobs+1);
lambda_cumul2 = zeros(1,firstobs+1);
for i=1:firstobs
    y0 = lambda_diff2_all(i);
    y1 = lambda_diff2_all(i+1);
    lambda_cumul1(i+1) = lambda_cumul1(i) * exp(h/2*(y0+y1));
end
lambda_diff_temp = lambda_cumul1/(lambda_cumul1(end)/lambda_diff(1));
for i=1:firstobs
    y0 = lambda_diff_temp(i);
    y1 = lambda_diff_temp(i+1);
    lambda_cumul2(i+1) = lambda_cumul2(i) + h/2*(y0+y1);
end
lambda_cumul_temp = lambda_cumul2/(lambda_cumul2(end)/lambda_grid_all(1));
lambda_diff_norm = [lambda_diff_temp, lambda_diff(2:end)];
lambda_cumul_norm = [lambda_cumul_temp(2:end), lambda_grid_all(2:end)];
lambda_diff = lambda_diff_norm;
lambda_temp = 1/h*diff(lambda_diff)./lambda_diff(2:end); 

%% Adapt rho to minimum value given

rho_diff_use = rho_diff;
if rho_min > 0 && rho_min < max(rho_diff)
    rho_diff_use = (rho_diff - min(rho_diff))*(max(rho_diff) - rho_min)/(max(rho_diff) - min(rho_diff)) + rho_min;
else
    rho_min = rho_diff(end)
end
    
%% Solving ODE on markup(mu) : Runge-Kunta Method of order 4
mu0 = 1.05;
func = @(x) mseodemumax(x,mu_last,lambda_diff,rho_diff_use,n,h);
mu0_opt = fminsearch(func,mu0,options); % Find initial value that matched moment
rho_temp = (ones(1,n)-rho_diff_use)./rho_diff_use; 
mu = zeros(1,n-1); % n-1 * 1 vector
mu(1) = mu0_opt;
for i=1:n-2
    a1 = lambda_temp(i);
    a2 = (lambda_temp(i)+lambda_temp(i+1))/2;
    a3 = lambda_temp(i+1);
    b1 = rho_temp(i+1);
    b2 = (rho_temp(i+1)+rho_temp(i+2))/2;
    b3 = rho_temp(i+2);
    mu(i+1) = rk4step(mu(i),h,a1,a2,a3,b1,b2,b3,@ydot1);
end

%% Solving ODE on productivity(Aa) : Runge-Kunta Method of order 4
mu_temp = (mu-ones(1,n-1))./rho_diff_use(2:end); 
AB = zeros(1,n-1);
AB(1) = 1; % initial value of productivity is 1 for type-0 firm
for i=1:n-2
    a1 = lambda_temp(i);
    a2 = (lambda_temp(i)+lambda_temp(i+1))/2;
    a3 = lambda_temp(i+1);
    b1 = mu_temp(i);
    b2 = (mu_temp(i)+mu_temp(i+1))/2;
    b3 = mu_temp(i+1);
    AB(i+1) = rk4step(AB(i),h,a1,a2,a3,b1,b2,b3,@ydot2);
end

%% Solving ODE on consumer surplus ratios (delta)

mu_hat = mu;
delta = zeros(1,n-1); 

delta(1) = delta_cutoff;
for i=1:n-2
    a1 = lambda_temp(i);
    a2 = (lambda_temp(i)+lambda_temp(i+1))/2;
    a3 = lambda_temp(i+1);
    b1 = mu_hat(i);
    b2 = (mu_hat(i)+mu_hat(i+1))/2;
    b3 = mu_hat(i+1);
    delta(i+1) = rk4step(delta(i),h,a1,a2,a3,b1,b2,b3,@ydot3);
end

rho = rho_diff_use(2:end);
shares = lambda_diff(2:end);
mu_bar = sum(shares)/sum(shares ./ mu);
ind_0 = find(mu <= mu_bar,1,'last');
AB = AB * mu(ind_0) / AB(ind_0);
p = mu ./ AB;
shares = shares ./ sum(shares) .* length(shares);
y = shares ./ p;

rho_under_lim = @(x) 1 + 0.*x;
rho_over_lim = @(x) rho_min + 0.*x;
rho_composite = @(x) rho_under_lim(x).*(x>p(1)) + interp1(p,rho,x,'linear','extrap').*(x<=p(1)).*(x>=p(end)) + rho_over_lim(x).*(x<p(end));
mu_under_lim = @(x) mu(1) + 0.*x;
mu_over_lim = @(x) mu(end) .* (x./p(end)).^(1-1/rho_min);
mu_composite = @(x) mu_under_lim(x).*(x>p(1)) + interp1(p,mu,x,'linear','extrap').*(x<=p(1)).*(x>=p(end)) + mu_over_lim(x).*(x<p(end));
logs_under_lim = @(x) 1/(1-mu(1)) .* log(x./p(1)) + log(shares(1));
logs_over_lim = @(x) -log(mu_over_lim(x) - 1)./(1-1/rho_min) + log(x) + log(shares(end)) - (-log(mu_over_lim(p(end)) - 1)./(1-1/rho_min) + log(p(end)));
logs_composite = @(x) logs_under_lim(x).*(x>p(1)) + interp1(p,log(shares),x,'linear','extrap').*(x<=p(1)).*(x>=p(end)) + logs_over_lim(x).*(x<p(end));
share_composite = @(x) exp(logs_composite(x));

delta_under_const = (delta(1) - mu(1)) / (p(1)^(1/(mu(1)-1)));
delta_under_lim = @(x) delta_under_const.*x.^(1/(mu(1)-1)) + mu(1);

share_over_x = @(x) share_composite(x) ./ x;
int_share_over_x = @(x) integral(share_over_x, x, p(end));
int_share_over_x_vec = @(x) arrayfun(int_share_over_x, x);
delta_over_lim_single = @(x) (delta(end)*shares(end) + share_composite(x) - shares(end) + int_share_over_x(x)) ./ share_composite(x);

delta_within = @(x) interp1(p,delta,x,'linear','extrap');
delta_composite_single = @(x) bound_switch({delta_over_lim_single, delta_within, delta_under_lim}, [p(end), p(1)], x);
delta_composite = @(x) arrayfun(delta_composite_single, x);

logp_over_lim = @(y_val) (mu(1)-1)/mu(1) .* (-log(y_val) + mu(1)/(mu(1)-1)*log(p(1)) + log(y(1)));
logp_under_lim = @(y_val) log(p(end)) + (rho_min/(rho_min-1)).*log((1 - 1/mu(end)).*(y_val./y(end)).^((1-rho_min)/rho_min) + 1/mu(end));
p_composite = @(y_val) exp(logp_over_lim(y_val)).*(y_val<y(1)) + interp1(y,p,y_val,'linear','extrap').*(y_val<=y(end)).*(y_val>=y(1)) + exp(logp_under_lim(y_val)).*(y_val>y(end));

rho_composite_y = @(y_val) rho_composite(p_composite(y_val));
mu_composite_y = @(y_val) mu_composite(p_composite(y_val));
share_composite_y = @(y_val) share_composite(p_composite(y_val));
delta_composite_y = @(y_val) delta_composite(p_composite(y_val));
Upsilon_composite_y = @(y_val) delta_composite(p_composite(y_val)) .* share_composite(p_composite(y_val));

end