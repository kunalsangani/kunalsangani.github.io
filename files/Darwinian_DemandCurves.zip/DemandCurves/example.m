clear
clc
close all

%% Example code: Demand curves calibrated non-parametrically from Belgian data

% The function hsa_fitting fits an HSA demand curve to the data
% Arguments: mu_max (markup of largest firm), delta_cutoff (consumer
% surplus ratio of smallest firm), rho_min (pass-through of largest firm)
% Note: If rho_min outside (0, 1), the function will use pass-through
% estimates from Amiti et al (2019).

% Example with a maximum markup of 1.7 and consumer surplus ratio at cutoff
% of 1.5
[share, rho, mu, delta, AB, p] = hsa_fitting(1.7, 1.5, 1);
% share, rho, mu, and delta are all functions which take relative prices
% p/P as an argument
% The producitivity/qualities AB and prices p are provided to replicate the
% distribution of sales shares in the Belgian VAT data.

% Example: Plot markup function mu(p/P) against price p/P
plot(p, mu(p))
figure;
% The function hdia_fitting fits an HDIA demand curve to the data
% Arguments: mu_max (markup of largest firm), delta_cutoff (consumer
% surplus ratio of smallest firm), rho_min (pass-through of largest firm)
% Note: If rho_min outside (0, 1), the function will use pass-through
% estimates from Amiti et al (2019).

% Example with a maximum markup of 2.5 and consumer surplus ratio at cutoff
% of 1.1
[Upsilon, share_y, rho_y, mu_y, delta_y, AB_y, y] = hdia_fitting(2.5, 1.1, 1);
% Upsilon, share_y, rho_y, mu_y, and delta_y are all functions which take 
% relative quantities y/Y as an argument
% The producitivity/qualities AB and quantities y are provided to replicate the
% distribution of sales shares in the Belgian VAT data.

% Example: Plot aggregator function Upsilon(y/Y) against relative quantities y/Y
plot(y, Upsilon(y))
