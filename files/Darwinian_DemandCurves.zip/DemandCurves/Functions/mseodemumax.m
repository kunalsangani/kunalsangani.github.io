
function mse = mseodemumax(mu0,mu_max,lambda_diff,rho_diff,n,h)
    lambda_temp = 1/h*diff(lambda_diff)./lambda_diff(2:end); % n-1 * 1 vector
    rho_temp = (ones(1,n)-rho_diff)./rho_diff; % n * 1 vector
    mu = zeros(1,n-1); % n-1 * 1 vector
    mu(1) = mu0; % initial value of markup is mu0 for type-0 firm
    for i=1:n-2
        a1 = lambda_temp(i);
        a2 = (lambda_temp(i)+lambda_temp(i+1))/2;
        a3 = lambda_temp(i+1);
        b1 = rho_temp(i+1);
        b2 = (rho_temp(i+1)+rho_temp(i+2))/2;
        b3 = rho_temp(i+2);
        mu(i+1) = rk4step(mu(i),h,a1,a2,a3,b1,b2,b3,@ydot1);
    end
    num = 0;
    denom = 0;
    for i=1:n-2
        num0 = lambda_diff(i+1)/mu(i);
        num1 = lambda_diff(i+2)/mu(i+1);
        denom0 = lambda_diff(i+1);
        denom1 = lambda_diff(i+2);
        %num = num + h/2*(num0+num1);
        %denom = denom + h/2*(denom0+denom1);        
    end
    mse = (mu(n-1) - mu_max)^2;
    %hmubar = 1/(num/denom);
    %mse = (hmubar - mu_bar)^2;
    
% tspan = [0 1];
% opts = odeset('RelTol',1e-2,'AbsTol',1e-4);
% [t,y] = ode45(@(t,y) markupdif(t,y,theta_grid,lambda_temp,rho_temp),tspan,ic,opts);
end