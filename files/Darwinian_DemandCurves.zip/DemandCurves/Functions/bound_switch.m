
function val = bound_switch(fun_arr,bounds_arr,x)   
    if x > bounds_arr(end)
        val = fun_arr{end}(x);
    else
        ind = find(x <= bounds_arr,1,'last');
        val = fun_arr{ind}(x);
    end
end