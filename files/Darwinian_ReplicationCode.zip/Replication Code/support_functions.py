import numpy as np
import pandas as pd
import pickle
from scipy.interpolate import interp1d
from scipy.stats import norm
import matplotlib.pyplot as plt
from scipy.optimize import minimize
import tikzplotlib
import os

# E_{weights}[arr]
def weighted_exp(arr, weights):
	return sum(arr * weights) / sum(weights)

# Cov_{weights}(arr1, arr2)
def weighted_cov(arr1, arr2, weights):
	return weighted_exp(arr1 * arr2, weights) - weighted_exp(arr1, weights) * weighted_exp(arr2, weights)

#############################################
# RK4 integration and Pareto functions
#############################################

def rk4step(y_last,theta_last,step_size,f):
	k1 = step_size * f(theta_last, y_last)
	k2 = step_size * f(theta_last + step_size/2, y_last + k1/2)
	k3 = step_size * f(theta_last + step_size/2, y_last + k2/2)
	k4 = step_size * f(theta_last + step_size, y_last + k3)
	return y_last + (1/6)*(k1 + 2*k2 + 2*k3 + k4)

def rk4_integrate(y_0, theta, f):
	y = np.ones(len(theta)) * y_0
	for i in range(1,len(theta)):
		y[i] = rk4step(y[i-1], theta[i-1], theta[i]-theta[i-1], f)
	return y

DATA_PATH = './Data/Prod_Ups_ODE.xlsx'
PRODUCT_DATA_PATH = './Data/Prod_Ups_ODE_product.xlsx'
def read_darwinian_data(pull_col=0, filename=DATA_PATH):
	xls = pd.ExcelFile(filename)
	p = pd.read_excel(filename, sheet_name=xls.sheet_names, header=None)
	# Some sheets have an extra row: This drops the first row(s) in sheets to even out
	lengths = [len(p[sheet_name]) for sheet_name in p]
	lengths = np.array(lengths) - min(lengths)
	for i,sheet_name in enumerate(p):
		if lengths[i] > 0:
			p[sheet_name] = p[sheet_name].drop(list(range(lengths[i])))
	lengths = [len(p[sheet_name]) for sheet_name in p]
	return list(p.keys()),[p[sheet_name][pull_col].to_numpy() for sheet_name in p]

# Generate markups to boundary (harmonic) average mu = mu_bar
def generate_markups(rho, shares, mu_bar, product=False):
	filename = './ODE_Store/mu_' + str(mu_bar) + '.store'
	if product:
		filename = './ODE_Store/mu_' + str(mu_bar) + '_product.store'
	if os.path.exists(filename):
		return np.fromfile(filename)
	theta = np.linspace(0, 1, len(rho)+2)[1:-1]
	rho_fn = interp1d(np.append([0], theta),np.append([1], rho))
	dloglambda = np.diff(np.log(shares)) / np.diff(theta)
	dloglambda_fn = interp1d(np.append([0], theta), np.append([dloglambda[0], dloglambda[0]], dloglambda))
	dmu = lambda theta,mu: mu*(mu-1)*(1-rho_fn(theta))/rho_fn(theta) * dloglambda_fn(theta)
	def mu_from_mu_0(mu_0, mu_bar):
		print('Trying: ', mu_0)
		mu = rk4_integrate(mu_0, theta, dmu)
		mu_bar_pred = 1/(weighted_exp(1/mu, shares))
		print('Predicted mu_bar: ', mu_bar_pred)
		return (mu_bar - mu_bar_pred)**2
	res = minimize(mu_from_mu_0, 1.001, args=(mu_bar), tol=1E-5)
	mu = rk4_integrate(res.x, theta, dmu)
	mu.tofile(filename)
	return mu

def generate_consumer_surplus_ratios(mu, shares, mu_bar, delta_bar, product=False):
	filename = './ODE_Store/delta_' + str(mu_bar) + '_' + str(delta_bar) + '.store'
	if product:
		filename = './ODE_Store/delta_' + str(mu_bar) + '_' + str(delta_bar) + '_product.store'
	if os.path.exists(filename):
		return np.fromfile(filename)
	theta = np.linspace(0, 1, len(mu)+2)[1:-1]
	mu_fn = interp1d(np.append([0], theta),np.append([1], mu))
	dloglambda = np.diff(np.log(shares)) / np.diff(theta)
	dloglambda_fn = interp1d(np.append([0], theta), np.append([dloglambda[0], dloglambda[0]], dloglambda))
	ddelta = lambda theta,delta: (mu_fn(theta)-delta) * dloglambda_fn(theta)
	def delta_from_delta_0(delta_0, delta_bar):
		print('Trying: ', delta_0)
		delta = rk4_integrate(delta_0, theta, ddelta)
		delta_bar_pred = weighted_exp(delta, shares)
		print('Predicted delta_bar: ', delta_bar_pred)
		return (delta_bar - delta_bar_pred)**2
	res = minimize(delta_from_delta_0, 1.001, args=(delta_bar), tol=1E-5)
	delta = rk4_integrate(res.x, theta, ddelta)
	delta.tofile(filename)
	return delta

def generate_consumer_surplus_ratios_effselection(mu, shares, mu_bar, product=False):
	filename = './ODE_Store/delta_' + str(mu_bar) + '_effselection.store'
	if product:
		filename = './ODE_Store/delta_' + str(mu_bar) + '_effselection_product.store'
	if os.path.exists(filename):
		return np.fromfile(filename)
	theta = np.linspace(0, 1, len(mu)+2)[1:-1]
	mu_fn = interp1d(np.append([0], theta),np.append([1], mu))
	dloglambda = np.diff(np.log(shares)) / np.diff(theta)
	dloglambda_fn = interp1d(np.append([0], theta), np.append([dloglambda[0], dloglambda[0]], dloglambda))
	ddelta = lambda theta,delta: (mu_fn(theta)-delta) * dloglambda_fn(theta)
	def delta_from_delta_0(delta_0):
		print('Trying: ', delta_0)
		delta = rk4_integrate(delta_0, theta, ddelta)
		delta_bar_pred = weighted_exp(delta, shares)
		print('Predicted delta_bar: ', delta_bar_pred)
		return (delta_0 - delta_bar_pred)**2
	res = minimize(delta_from_delta_0, 1.001, tol=1E-8)
	delta = rk4_integrate(res.x, theta, ddelta)
	delta.tofile(filename)
	return delta

def generate_consumer_surplus_ratios_cutoff(mu, shares, mu_bar, delta_cutoff, product=False):
	filename = './ODE_Store/delta_' + str(mu_bar) + '_cutoff_' + str(delta_cutoff) + '.store'
	if product:
		filename = './ODE_Store/delta_' + str(mu_bar) + '_cutoff_' + str(delta_cutoff) + '_product.store'
	if os.path.exists(filename):
		return np.fromfile(filename)
	theta = np.linspace(0, 1, len(mu)+2)[1:-1]
	mu_fn = interp1d(np.append([0], theta),np.append([1], mu))
	dloglambda = np.diff(np.log(shares)) / np.diff(theta)
	dloglambda_fn = interp1d(np.append([0], theta), np.append([dloglambda[0], dloglambda[0]], dloglambda))
	ddelta = lambda theta,delta: (mu_fn(theta)-delta) * dloglambda_fn(theta)
	delta = rk4_integrate(delta_cutoff, theta, ddelta)
	delta.tofile(filename)
	return delta

keys,variables = read_darwinian_data()
rho = variables[keys.index('rho')]
shares = variables[keys.index('lambda')]
theta = np.linspace(0, 1, len(rho)+2)[1:-1]

keys_product,variables_product = read_darwinian_data(filename=PRODUCT_DATA_PATH)
rho_product = variables_product[keys_product.index('rho')]
shares_product = variables_product[keys_product.index('lambda')]

def generate_all_variables(mu_bar, effselection=True, delta_bar=1.09):
	mu = generate_markups(rho, shares, mu_bar)
	A = np.ones(len(mu))
	for i in range(1,len(A)):
		A[i] = np.exp(np.log(A[i-1]) + (mu[i-1]-1)/rho[i-1] * (np.log(shares[i]) - np.log(shares[i-1])))
	if effselection:
		delta = generate_consumer_surplus_ratios_effselection(mu, shares, mu_bar)
	else:
		delta = generate_consumer_surplus_ratios(mu, shares, mu_bar, delta_bar)
	return rho,shares,mu,A,delta

def generate_all_variables_product(mu_bar, effselection=True, delta_bar=1.09):
	mu_product = generate_markups(rho_product, shares_product, mu_bar, product=True)
	A_product = np.ones(len(mu_product))
	for i in range(1,len(A_product)):
		A_product[i] = np.exp(np.log(A_product[i-1]) + (mu_product[i-1]-1)/rho_product[i-1] * (np.log(shares_product[i]) - np.log(shares_product[i-1])))
	if effselection:
		delta_product = generate_consumer_surplus_ratios_effselection(mu_product, shares_product, mu_bar, product=True)
	else:
		delta_product = generate_consumer_surplus_ratios(mu_product, shares_product, mu_bar, delta_bar, product=True)
	return rho_product,shares_product,mu_product,A_product,delta_product

def generate_all_variables_deltacutoff(mu_bar, delta_cutoff=1.09):
	mu = generate_markups(rho, shares, mu_bar)
	A = np.ones(len(mu))
	for i in range(1,len(A)):
		A[i] = np.exp(np.log(A[i-1]) + (mu[i-1]-1)/rho[i-1] * (np.log(shares[i]) - np.log(shares[i-1])))
	delta = generate_consumer_surplus_ratios_cutoff(mu, shares, mu_bar, delta_cutoff)
	return rho,shares,mu,A,delta

