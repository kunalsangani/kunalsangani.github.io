function yp=rk4step_scalar_fr(y,index_star,index_end,hL,lambda,yt,vp,mu,tau,data,nodes,weights,kappa,bound,ydot_scalar_fr)
    %one step of the Runge-Kutta order 4 method
    
    s1 = ydot_scalar_fr(y,index_star,index_end,lambda,yt,vp,mu,tau,data,nodes,weights,kappa,bound);
    s2 = ydot_scalar_fr(y+hL*s1/2,index_star,index_end,lambda,yt,vp,mu,tau,data,nodes,weights,kappa,bound);
    s3 = ydot_scalar_fr(y+hL*s2/2,index_star,index_end,lambda,yt,vp,mu,tau,data,nodes,weights,kappa,bound);
    s4 = ydot_scalar_fr(y+hL*s3,index_star,index_end,lambda,yt,vp,mu,tau,data,nodes,weights,kappa,bound);
    yp_all = y+hL*(s1+2*s2+2*s3+s4)/6;
    
    if bound(2) == 1 % bound theta_star
    
        if yp_all(1) < y(1) && y(1) == 0.15
            theta_star = 0.15;
        elseif yp_all(1) > 0.995
            theta_star = 0.995;
        else
            theta_star = yp_all(1); % \theta^*
        end
        
        yp = [theta_star, yp_all(2:end)];

    elseif bound(2) == 0
        
        if bound(3) == 1 % restrict theta_star to 0.15
            yp = [0.15, yp_all(2:end)];
        else
            yp = yp_all;
        end
    end
end