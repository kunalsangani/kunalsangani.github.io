function yp=rk4step_mu_fr(y,index_star,index_end,hL,lambda,yt,vp,mu,tau,data,nodes,weights,kappa,bound,ydot_mu_fr)
    %one step of the Runge-Kutta order 4 method
    
    s1 = ydot_mu_fr(y,index_star,index_end,lambda,yt,vp,mu,tau,data,nodes,weights,kappa,bound);
    s2 = ydot_mu_fr(y,index_star,index_end,lambda,yt,vp,mu+hL*s1/2,tau,data,nodes,weights,kappa,bound);
    s3 = ydot_mu_fr(y,index_star,index_end,lambda,yt,vp,mu+hL*s2/2,tau,data,nodes,weights,kappa,bound);
    s4 = ydot_mu_fr(y,index_star,index_end,lambda,yt,vp,mu+hL*s3,tau,data,nodes,weights,kappa,bound);
    yp = mu+hL*(s1+2*s2+2*s3+s4)/6;
end