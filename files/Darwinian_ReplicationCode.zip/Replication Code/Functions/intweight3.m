
function int = intweight3(x,weight,n,h)
    num = 0;
    denom = 0;
    for i=1:n-2
        num0 = weight(i)*x(i);
        num1 = weight(i+1)*x(i+1);
        denom0 = weight(i);
        denom1 = weight(i+1);
        num = num + h/2*(num0+num1);
        denom = denom + h/2*(denom0+denom1);
    end
    int = num/denom; % Exp_lambda(delta)
end