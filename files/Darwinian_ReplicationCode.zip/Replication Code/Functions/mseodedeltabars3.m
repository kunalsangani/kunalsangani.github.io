
function mse = mseodedeltabars3(delta0,mu,lambda_diff,n,h)
    lambda_temp = 1/h*diff(lambda_diff)./lambda_diff(2:end); % n-1 * 1 vector
    mu_hat = mu;  % n-1 * 1 vector
    delta = zeros(1,n-1); % n-1 * 1 vector
    delta(1) = delta0; % initial value of surplus ratio is mu0 for type-0 firm
    for i=1:n-2
        a1 = lambda_temp(i);
        a2 = (lambda_temp(i)+lambda_temp(i+1))/2;
        a3 = lambda_temp(i+1);
        b1 = mu_hat(i);
        b2 = (mu_hat(i)+mu_hat(i+1))/2;
        b3 = mu_hat(i+1);
        delta(i+1) = rk4step(delta(i),h,a1,a2,a3,b1,b2,b3,@ydot3);
    end
    num = 0;
    denom = 0;
    for i=1:n-2
        num0 = lambda_diff(i+1)*delta(i);
        num1 = lambda_diff(i+2)*delta(i+1);
        denom0 = lambda_diff(i+1);
        denom1 = lambda_diff(i+2);
        num = num + h/2*(num0+num1);
        denom = denom + h/2*(denom0+denom1);        
    end
    deltabar = num/denom;
    mse = (deltabar - delta0)^2;
    
% tspan = [0 1];
% opts = odeset('RelTol',1e-2,'AbsTol',1e-4);
% [t,y] = ode45(@(t,y) markupdif(t,y,theta_grid,lambda_temp,rho_temp),tspan,ic,opts);
end