
function elast = mu_A_elas(y,mu,index_star,index_end,nodes,data)
    % evaluate elasticity of mu with respect to A at selection cutoff
    
    weight_index = floor(index_end*nodes)+1;
    Prod = data(:,8);

    num = mu(1) - y(10); % log(mu(first node)) - log(mu_theta_star)
    denom = log(Prod(weight_index(1))) - log(Prod(index_star));
    % log(A(first node)) - log(A(theta_star))
    
    elast = num/denom;
end