
function z=ydot2(w,a,b)
    z = w*a*b;
end