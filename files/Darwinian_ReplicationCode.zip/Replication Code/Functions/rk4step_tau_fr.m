function yp=rk4step_tau_fr(y,index_star,index_end,hL,lambda,yt,vp,mu,tau,data,nodes,weights,kappa,bound,ydot_tau_fr)
    %one step of the Runge-Kutta order 4 method
    
    s1 = ydot_tau_fr(y,index_star,index_end,lambda,yt,vp,mu,tau,data,nodes,weights,kappa,bound);
    s2 = ydot_tau_fr(y,index_star,index_end,lambda,yt,vp,mu,tau+hL*s1/2,data,nodes,weights,kappa,bound);
    s3 = ydot_tau_fr(y,index_star,index_end,lambda,yt,vp,mu,tau+hL*s2/2,data,nodes,weights,kappa,bound);
    s4 = ydot_tau_fr(y,index_star,index_end,lambda,yt,vp,mu,tau+hL*s3,data,nodes,weights,kappa,bound);
    yp = tau+hL*(s1+2*s2+2*s3+s4)/6;
end