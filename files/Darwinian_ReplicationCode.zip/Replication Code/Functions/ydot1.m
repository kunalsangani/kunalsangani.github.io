
function z=ydot1(w,a,b)
    z = w*(w-1)*a*b;
end