
function sigma_theta_node = sigma_theta_hom(y_theta,index_star,index_end,data)
    % mapping from y_theta_star to sigma_theta_star (f1(y(1)))
    
    % y(1) = \theta^*, y(2) = \logM, y(3) = d\logP, y(4) = d\logY
    % y(5) = \bar{\delta}, y(6) = \log(\frac{y_{\theta^*}}{Y})
    % mu=\mu_\theta, lambda=\lambda_\theta, yt=log(\frac{y_\theta}{Y})
    % data = [ytheta', Upsdata', mudata', sigmadata', rhodata', deltadata'];

%     index = floor(n*theta_star)+1;
%     y_theta_star = data(index,1);
    ytheta = data(:,1);
    index = zeros(1,1);
    
        for j=index_star:index_end-1
            if (ytheta(j)<y_theta && y_theta<ytheta(j+1)) || y_theta == ytheta(j) 
                index = j;
            elseif y_theta < ytheta(index_star)
                index = index_star;
            elseif y_theta > ytheta(index_end)
                index = index_end;
            end
        end
    sigma_theta_node = data(index,4)';

end