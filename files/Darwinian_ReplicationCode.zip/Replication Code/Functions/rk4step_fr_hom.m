function yp=rk4step_fr_hom(y,index_star,index_end,hL,data,kappa,ydot_fr_hom)
    %one step of the Runge-Kutta order 4 method
    
    s1 = ydot_fr_hom(y,index_star,index_end,data,kappa);
    s2 = ydot_fr_hom(y+hL*s1/2,index_star,index_end,data,kappa);
    s3 = ydot_fr_hom(y+hL*s2/2,index_star,index_end,data,kappa);
    s4 = ydot_fr_hom(y+hL*s3,index_star,index_end,data,kappa);
    yp = y+hL*(s1+2*s2+2*s3+s4)/6;

end