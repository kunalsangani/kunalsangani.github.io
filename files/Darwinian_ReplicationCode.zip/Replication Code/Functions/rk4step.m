function y=rk4step(w,h,a1,a2,a3,b1,b2,b3,ydot)
    %one step of the Runge-Kutta order 4 method
    s1 = ydot(w,a1,b1);
    s2 = ydot(w+h*s1/2,a2,b2);
    s3 = ydot(w+h*s2/2,a2,b2);
    s4 = ydot(w+h*s3,a3,b3);
    y = w+h*(s1+2*s2+2*s3+s4)/6;
end