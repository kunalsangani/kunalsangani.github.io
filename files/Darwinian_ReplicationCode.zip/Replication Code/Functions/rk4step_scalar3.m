function yp=rk4step_scalar3(y,index_star,index_end,hL,lambda,yt,data,nodes,weights,ydot_scalar3)
    %one step of the Runge-Kutta order 4 method
    
    s1 = ydot_scalar3(y,index_star,index_end,lambda,yt,data,nodes,weights);
    s2 = ydot_scalar3(y+hL*s1/2,index_star,index_end,lambda,yt,data,nodes,weights);
    s3 = ydot_scalar3(y+hL*s2/2,index_star,index_end,lambda,yt,data,nodes,weights);
    s4 = ydot_scalar3(y+hL*s3,index_star,index_end,lambda,yt,data,nodes,weights);
    yp = y+hL*(s1+2*s2+2*s3+s4)/6;
end