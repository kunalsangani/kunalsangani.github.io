function yp=rk4step_lambda_fr(y,index_star,index_end,hL,lambda,yt,vp,mu,tau,data,nodes,weights,kappa,bound,ydot_lambda_fr)
    %one step of the Runge-Kutta order 4 method
    
    s1 = ydot_lambda_fr(y,index_star,index_end,lambda,yt,vp,mu,tau,data,nodes,weights,kappa,bound);
    s2 = ydot_lambda_fr(y,index_star,index_end,lambda+hL*s1/2,yt,vp,mu,tau,data,nodes,weights,kappa,bound);
    s3 = ydot_lambda_fr(y,index_star,index_end,lambda+hL*s2/2,yt,vp,mu,tau,data,nodes,weights,kappa,bound);
    s4 = ydot_lambda_fr(y,index_star,index_end,lambda+hL*s3,yt,vp,mu,tau,data,nodes,weights,kappa,bound);
    yp = lambda+hL*(s1+2*s2+2*s3+s4)/6;
end