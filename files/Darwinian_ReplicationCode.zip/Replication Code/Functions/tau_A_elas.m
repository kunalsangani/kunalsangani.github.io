
function elast = tau_A_elas(y,tau,index_star,index_end,nodes,data)
    % evaluate elasticity of mu with respect to A at selection cutoff
    
    weight_index = floor(index_end*nodes)+1;
    Prod = data(:,8);

    num = tau(1) - y(11); % log(tau(first node)) - log(tau_theta_star)
    denom = log(Prod(weight_index(1))) - log(Prod(index_star));
    % log(A(first node)) - log(A(theta_star))
    
    elast = num/denom;
end