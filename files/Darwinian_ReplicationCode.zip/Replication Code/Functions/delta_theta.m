
function delta_theta_node = delta_theta(y_theta,index_star,index_end,data,nodes)
    % mapping from y_theta_star to delta_theta
    
    % y(1) = \theta^*, y(2) = \logM, y(3) = d\logP, y(4) = d\logY
    % y(5) = \bar{\delta}, y(6) = \log(\frac{y_{\theta^*}}{Y})
    % mu=\mu_\theta, lambda=\lambda_\theta, yt=log(\frac{y_\theta}{Y})
    % data = [ytheta', Upsdata', mudata', sigmadata', rhodata', deltadata'];

%     index = floor(n*theta_star)+1;
%     y_theta_star = data(index,1);
    ytheta = data(:,1);
    N = length(nodes);
    index = zeros(N,1);
    
    for i=1:N
        for j=index_star:index_end-1
            if (ytheta(j)<y_theta(i) && y_theta(i)<ytheta(j+1)) || y_theta(i) == ytheta(j) 
                index(i) = j;
            elseif y_theta(i) < ytheta(index_star)
                index(i) = index_star;
            elseif y_theta(i) > ytheta(index_end)
                index(i) = index_end;
            end
        end
    end
    delta_theta_node = data(index,6)';

end