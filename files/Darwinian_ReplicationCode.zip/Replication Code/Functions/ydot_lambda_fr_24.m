
function ydot = ydot_lambda_fr_24(y,index_star,index_end,lambda,yt,vp,mu,tau,data,nodes,weights,kappa,bound)

    % y(1) = \theta^*, y(2) = \log(M), y(3) = \log(P), y(4) = \log(Y)
    % y(5) = \log(\bar{\delta}), y(6) = \log(\Lambda_L)
    % y(7) = \log(\lambda_{\theta^*})
    % y(8) = \log(\frac{y_{\theta^*}}{Y})
    % y(9) = \log(Variable Profit at \theta^*)
    % y(10) = \log(\mu_{\theta^*}), y(11) = \log(\tau_{\theta^*})
    % lambda=\log(\lambda_\theta), yt=\log(\frac{y_\theta}{Y})
    % vp = \log(Variable Profit)
    % mu = \log(\mu_\theta), tau = \log(\tau_\theta)
    % data = [ytheta', Upsdata', mudata', sigmadata', rhodata', deltadata',lambdadata',Prod'];
     
    % define auxiliary variables
    f1_y1 = sigma_theta_star(exp(y(8)),index_star,index_end,data);
    f2_y1 = dlogA_theta_star2(y(1),index_end,data);
%     f3_y1 = lambda_theta_star(y(1),exp(y(6)),exp(y(2)),...
%         mu_theta_star(exp(y(6)),n,data),A_theta_star(y(1),x1),exp(y(4)));
    f4_y1 = delta_theta_star(exp(y(8)),index_star,index_end,data);
    f5_y1 = rho_theta_star(exp(y(8)),index_star,index_end,data);
    f6_y1 = mu_A_elas(y,mu,index_star,index_end,nodes,data);
    f7_y1 = tau_A_elas(y,tau,index_star,index_end,nodes,data);
    
%     A_theta_node = A_theta(y(1),x1,nodes);
    sigma_theta_node = sigma_theta(exp(yt),index_star,index_end,data,nodes);
    rho_theta_node = rho_theta(exp(yt),index_star,index_end,data,nodes);
%     mu_theta_node = mu_theta(exp(yt),index_star,index_end,data,nodes);
    lambda_theta_node = exp(lambda);
    mu_theta_node = exp(mu);
    vp_theta_node = exp(vp);
    tau_theta_node = exp(tau);
    delta_theta_node = delta_theta(exp(yt),index_star,index_end,data,nodes);
%    lambda_theta_node = lambda_theta(y(1),exp(yt),exp(y(2)),...
%        mu_theta_node,A_theta_node,exp(y(4)));
    
    A_y1 = 0; B_y1 = 0; B1_y1 = 0; B2_y1 = 0; B3_y1 = 0; B4_y1 = 0; 
    C_y1 = 0; D_y1 = 0; E_y1 = 0; F_y1 = 0; G_y1 = 0;
    for j=1:length(nodes)
        A_y1 = A_y1 + weights(j)*lambda_theta_node(j)*(sigma_theta_node(j)-1)*...
            double(nodes(j)>=y(1))/(1-y(1));
        B_y1 = B_y1 + weights(j)*lambda_theta_node(j)*(sigma_theta_node(j)-1)*...
            (-kappa(1)*(log(mu_theta_node(j))-log(delta_theta_node(j)))-kappa(2)*(log(tau_theta_node(j))-log(1/delta_theta_node(j))))*...
            double(nodes(j)>=y(1))/(1-y(1));
        B1_y1 = B1_y1 + weights(j)*vp_theta_node(j)*...
            double(nodes(j)>=y(1))/(1-y(1));
        B2_y1 = B2_y1 + weights(j)*vp_theta_node(j)*sigma_theta_node(j)*...
            double(nodes(j)>=y(1))/(1-y(1));
        B3_y1 = B3_y1 + weights(j)*vp_theta_node(j)*sigma_theta_node(j)*...
            ((-kappa(2))*(log(tau_theta_node(j))-log(1/delta_theta_node(j))))*...
            double(nodes(j)>=y(1))/(1-y(1));
        B4_y1 = B4_y1 + weights(j)*vp_theta_node(j)*...
            (1/(mu_theta_node(j)-1)-(sigma_theta_node(j)-1))*...
            ((-kappa(1))*(log(mu_theta_node(j))-log(delta_theta_node(j))))*...
            double(nodes(j)>=y(1))/(1-y(1));
        C_y1 = C_y1 + weights(j)*lambda_theta_node(j)*...
            double(nodes(j)>=y(1))/(1-y(1));
        D_y1 = D_y1 + weights(j)*lambda_theta_node(j)*...
            (-kappa(1)*(log(mu_theta_node(j))-log(delta_theta_node(j)))-kappa(2)*(log(tau_theta_node(j))-log(1/delta_theta_node(j))))*...
            double(nodes(j)>=y(1))/(1-y(1));
        E_y1 = E_y1 + weights(j)*lambda_theta_node(j)/tau_theta_node(j)*...
            double(nodes(j)>=y(1))/(1-y(1));
        F_y1 = F_y1 + weights(j)*lambda_theta_node(j)/tau_theta_node(j)*sigma_theta_node(j)*...
            double(nodes(j)>=y(1))/(1-y(1));
        G_y1 = G_y1 + weights(j)*lambda_theta_node(j)/tau_theta_node(j)*...
            ((sigma_theta_node(j)-1)*(-kappa(1))*(log(mu_theta_node(j))-log(delta_theta_node(j)))+...
            sigma_theta_node(j)*(-kappa(2))*(log(tau_theta_node(j))-log(1/delta_theta_node(j))))*...
            double(nodes(j)>=y(1))/(1-y(1));
    end

    H_theta = sigma_theta_node;
    I_theta = delta_theta_node;
    
    Nnode = length(nodes);
    
    pass = 1;
    bound = 0;
    
    while pass
    % system of ODE
    if bound == 0 % not retrict theta_star to 0.15
    
    M1 = [0, 1/((f1_y1-1)*f2_y1+1/(1-y(1))), 0, 0, 0, 0, 0, 0, -1/((f1_y1-1)*f2_y1+1/(1-y(1))), 0, 0, zeros(1,5*Nnode)];
%     M2 = [exp(y(7))/(1-y(1)), 0, -1-A_y1, -1, 0, A_y1, 0, 0, 0, 0, 0, zeros(1,5*Nnode)]; 
    M2 = [0, 1, B2_y1/B1_y1, 1, 0, -B2_y1/B1_y1, 0, 0, 0, 0, 0, zeros(1,5*Nnode)];
    M3 = [exp(y(7))/((1+A_y1/C_y1)*(1-y(1))), -1/(1+A_y1/C_y1), 0, -1/(1+A_y1/C_y1), 0, (A_y1/C_y1)/(1+A_y1/C_y1), 0, 0, 0, 0, 0, zeros(1,5*Nnode)]; 
    M4 = [-(f4_y1-1)*exp(y(7))/(1-y(1)), exp(y(5))-1, 0, 0, 0, -1, 0, 0, 0, 0, 0, zeros(1,5*Nnode)]; 
    M5 = [0, 0, 1, 1, 0, 0, 0, 0, 0, 0, 0, zeros(1,5*Nnode)]; 
    M6 = [-exp(y(7))/(exp(y(11))*(1-y(1))*E_y1), 1, F_y1/E_y1, 1, 0, 1-F_y1/E_y1, 0, 0, 0, 0, 0, zeros(1,5*Nnode)]; 
    M7 = [(f1_y1-1)*f2_y1-1/(1-y(1)), 1, f1_y1, 1, 0, 1-f1_y1, 0, 0, 0, 1-f1_y1, 1-f1_y1, zeros(1,5*Nnode)]; 
    M8 = [f1_y1*f2_y1, 0, f1_y1, 0, 0, -f1_y1, 0, 0, 0, -f1_y1, -f1_y1, zeros(1,5*Nnode)]; 
    M9 = [0, 0, 0, 0, 0, -1, 1, 0, 0, 1/(exp(y(10))-1), -1, zeros(1,5*Nnode)]; 
    M10 = [f2_y1*f6_y1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, zeros(1,5*Nnode)]; 
    M11 = [f2_y1*f7_y1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, zeros(1,5*Nnode)]; 
    
    M12 = [ones(Nnode,1)*(-1)/(1-y(1)), ones(Nnode,1), H_theta', ones(Nnode,1),...
        zeros(Nnode,1), -H_theta'+ones(Nnode,1), zeros(Nnode,1), zeros(Nnode,1),...
        zeros(Nnode,1), zeros(Nnode,1), zeros(Nnode,1), zeros(Nnode,Nnode), zeros(Nnode,Nnode),...
        zeros(Nnode,Nnode), -diag(H_theta)+eye(Nnode), -diag(H_theta)+eye(Nnode)];
    M13 = [zeros(Nnode,1), zeros(Nnode,1), H_theta', zeros(Nnode,1), ...
        zeros(Nnode,1), -H_theta', zeros(Nnode,1), zeros(Nnode,1), ...
        zeros(Nnode,1), zeros(Nnode,1), zeros(Nnode,1), zeros(Nnode,Nnode), zeros(Nnode,Nnode),...
        zeros(Nnode,Nnode), -diag(H_theta), -diag(H_theta)];
    M14 = [zeros(Nnode,1), zeros(Nnode,1), zeros(Nnode,1), zeros(Nnode,1), ...
        zeros(Nnode,1), -ones(Nnode,1), zeros(Nnode,1), zeros(Nnode,1), ...
        zeros(Nnode,1), zeros(Nnode,1), zeros(Nnode,1), eye(Nnode), zeros(Nnode,Nnode),...
        zeros(Nnode,Nnode), diag(1./(exp(mu)-1)), -eye(Nnode)];
    M15 = [zeros(Nnode,1), zeros(Nnode,1), zeros(Nnode,1), zeros(Nnode,1), ...
        zeros(Nnode,1), zeros(Nnode,1), zeros(Nnode,1), zeros(Nnode,1), ...
        zeros(Nnode,1), zeros(Nnode,1), zeros(Nnode,1), zeros(Nnode,Nnode), zeros(Nnode,Nnode),...
        zeros(Nnode,Nnode), zeros(Nnode,Nnode), zeros(Nnode,Nnode)];
    M16 = [zeros(Nnode,1), zeros(Nnode,1), zeros(Nnode,1), zeros(Nnode,1), ...
        zeros(Nnode,1), zeros(Nnode,1), zeros(Nnode,1), zeros(Nnode,1), ...
        zeros(Nnode,1), zeros(Nnode,1), zeros(Nnode,1), zeros(Nnode,Nnode), zeros(Nnode,Nnode),...
        zeros(Nnode,Nnode), zeros(Nnode,Nnode), zeros(Nnode,Nnode)];
%     Mstar = [0, 0, G_theta_star, 0, 0, zeros(1,Nnode), 0]; 
    M = [M1 ; M2 ; M3 ; M4 ; M5 ; M6 ; M7 ; M8 ; M9 ; M10 ; M11 ; M12 ; M13 ; M14 ; M15 ; M16];
    V = [0; (B4_y1-B3_y1)/B1_y1; (B_y1/C_y1)/(1+A_y1/C_y1); -D_y1/C_y1; 0; -G_y1/E_y1; 0; 0; 0; ...
        -kappa(1)*(y(10)-log(f4_y1)); -kappa(2)*(y(11)-log(1/f4_y1)); zeros(3*Nnode,1) ;...
        -kappa(1)*(mu'-log(I_theta')) ; -kappa(2)*(tau'-log(1./I_theta')) ];
    
    N_all = 11+Nnode*5;
    
    % output
    ydot_all = inv(eye(N_all)-M)*V;
    
    elseif bound == 1 % restrict theta_star to 0.15 (d theta_star = 0)
        
%     M1 = [0, 1/((f1_y1-1)*f2_y1+1/(1-y(1))), 0, 0, 0, 0, 0, 0, -1/((f1_y1-1)*f2_y1+1/(1-y(1))), 0, 0, zeros(1,5*Nnode)];
%     M2 = [exp(y(7))/(1-y(1)), 0, -1-A_y1, -1, 0, A_y1, 0, 0, 0, 0, 0, zeros(1,5*Nnode)]; 
    M2 = [1, B2_y1/B1_y1, 1, 0, -B2_y1/B1_y1, 0, 0, 0, 0, 0, zeros(1,5*Nnode)];
    M3 = [-1/(1+A_y1/C_y1), 0, -1/(1+A_y1/C_y1), 0, (A_y1/C_y1)/(1+A_y1/C_y1), 0, 0, 0, 0, 0, zeros(1,5*Nnode)]; 
    M4 = [exp(y(5))-1, 0, 0, 0, -1, 0, 0, 0, 0, 0, zeros(1,5*Nnode)]; 
    M5 = [0, 1, 1, 0, 0, 0, 0, 0, 0, 0, zeros(1,5*Nnode)]; 
    M6 = [1, F_y1/E_y1, 1, 0, 1-F_y1/E_y1, 0, 0, 0, 0, 0, zeros(1,5*Nnode)]; 
    M7 = [1, f1_y1, 1, 0, 1-f1_y1, 0, 0, 0, 1-f1_y1, 1-f1_y1, zeros(1,5*Nnode)]; 
    M8 = [0, f1_y1, 0, 0, -f1_y1, 0, 0, 0, -f1_y1, -f1_y1, zeros(1,5*Nnode)]; 
    M9 = [0, 0, 0, 0, -1, 1, 0, 0, 1/(exp(y(10))-1), -1, zeros(1,5*Nnode)]; 
    M10 = [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, zeros(1,5*Nnode)]; 
    M11 = [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, zeros(1,5*Nnode)]; 
    
    M12 = [ones(Nnode,1), H_theta', ones(Nnode,1),...
        zeros(Nnode,1), -H_theta'+ones(Nnode,1), zeros(Nnode,1), zeros(Nnode,1),...
        zeros(Nnode,1), zeros(Nnode,1), zeros(Nnode,1), zeros(Nnode,Nnode), zeros(Nnode,Nnode),...
        zeros(Nnode,Nnode), -diag(H_theta)+eye(Nnode), -diag(H_theta)+eye(Nnode)];
    M13 = [zeros(Nnode,1), H_theta', zeros(Nnode,1), ...
        zeros(Nnode,1), -H_theta', zeros(Nnode,1), zeros(Nnode,1), ...
        zeros(Nnode,1), zeros(Nnode,1), zeros(Nnode,1), zeros(Nnode,Nnode), zeros(Nnode,Nnode),...
        zeros(Nnode,Nnode), -diag(H_theta), -diag(H_theta)];
    M14 = [zeros(Nnode,1), zeros(Nnode,1), zeros(Nnode,1), ...
        zeros(Nnode,1), -ones(Nnode,1), zeros(Nnode,1), zeros(Nnode,1), ...
        zeros(Nnode,1), zeros(Nnode,1), zeros(Nnode,1), eye(Nnode), zeros(Nnode,Nnode),...
        zeros(Nnode,Nnode), diag(1./(exp(mu)-1)), -eye(Nnode)];
    M15 = [zeros(Nnode,1), zeros(Nnode,1), zeros(Nnode,1), ...
        zeros(Nnode,1), zeros(Nnode,1), zeros(Nnode,1), zeros(Nnode,1), ...
        zeros(Nnode,1), zeros(Nnode,1), zeros(Nnode,1), zeros(Nnode,Nnode), zeros(Nnode,Nnode),...
        zeros(Nnode,Nnode), zeros(Nnode,Nnode), zeros(Nnode,Nnode)];
    M16 = [zeros(Nnode,1), zeros(Nnode,1), zeros(Nnode,1), ...
        zeros(Nnode,1), zeros(Nnode,1), zeros(Nnode,1), zeros(Nnode,1), ...
        zeros(Nnode,1), zeros(Nnode,1), zeros(Nnode,1), zeros(Nnode,Nnode), zeros(Nnode,Nnode),...
        zeros(Nnode,Nnode), zeros(Nnode,Nnode), zeros(Nnode,Nnode)];
%     Mstar = [0, 0, G_theta_star, 0, 0, zeros(1,Nnode), 0]; 
    M = [M2 ; M3 ; M4 ; M5 ; M6 ; M7 ; M8 ; M9 ; M10 ; M11 ; M12 ; M13 ; M14 ; M15 ; M16];
    V = [(B4_y1-B3_y1)/B1_y1; (B_y1/C_y1)/(1+A_y1/C_y1); -D_y1/C_y1; 0; -G_y1/E_y1; 0; 0; 0; ...
        -kappa(1)*(y(10)-log(f4_y1)); -kappa(2)*(y(11)-log(1/f4_y1)); zeros(3*Nnode,1) ;...
        -kappa(1)*(mu'-log(I_theta')) ; -kappa(2)*(tau'-log(1./I_theta')) ];
    
        
    N_all = 10+Nnode*5; % theta_star is constant, not variable
    
    % output
    ydot_all = [0 ; inv(eye(N_all)-M)*V];
        
    end
    
    if ydot_all(1) < 0 && y(1) == 0.15
        bound = 1;
    else
        pass = 0;
    end
    

    
    end

    ydot = ydot_all(12:Nnode+11)';

%     ydot(1) = ydot_all(1); % \theta^*
%     ydot(2) = ydot_all(2); % \logM
%     ydot(3) = ydot_all(3); % \logP
%     ydot(4) = ydot_all(4); % \logY
%     ydot(5) = ydot_all(5); % \log(\bar{\delta})
%     ydot(6) = ydot_all(6); % \log(\Lambda_L)
%     ydot(7) = ydot_all(7); % \log(\lambda_{\theta^*})
%     ydot(8) = ydot_all(8); % \log(\frac{y_{\theta^*}}{Y})
%     ydot(9) = ydot_all(9); % \log(Varible Profit at \theta^*)
%     ydot(10) = ydot_all(10); % \log(\mu_{\theta^*})
%     ydot(11) = ydot_all(11); % \log(\tau_{\theta^*})
    
    
end