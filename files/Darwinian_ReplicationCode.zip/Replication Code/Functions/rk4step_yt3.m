function yp=rk4step_yt3(y,index_star,index_end,hL,lambda,yt,data,nodes,weights,ydot_yt3)
    %one step of the Runge-Kutta order 4 method
    
    s1 = ydot_yt3(y,index_star,index_end,lambda,yt,data,nodes,weights);
    s2 = ydot_yt3(y,index_star,index_end,lambda,yt+hL*s1/2,data,nodes,weights);
    s3 = ydot_yt3(y,index_star,index_end,lambda,yt+hL*s2/2,data,nodes,weights);
    s4 = ydot_yt3(y,index_star,index_end,lambda,yt+hL*s3,data,nodes,weights);
    yp = yt+hL*(s1+2*s2+2*s3+s4)/6;
end