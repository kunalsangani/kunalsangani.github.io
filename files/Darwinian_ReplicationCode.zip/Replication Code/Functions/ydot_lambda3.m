
function ydot = ydot_lambda3(y,index_star,index_end,lambda,yt,data,nodes,weights)

    % y(1) = \theta^*, y(2) = \logM, y(3) = d\logP, y(4) = d\logY
    % y(5) = \log(\bar{\delta}), y(6) = \log(\lambda_{\theta^*})
    % y(7) = \log(\frac{y_{\theta^*}}{Y})
    % lambda=\log\lambda_\theta, yt=log(\frac{y_\theta}{Y})
    % data = [ytheta', Upsdata', mudata', sigmadata', rhodata', deltadata',lambdadata',Prod'];
     
    % define auxiliary variables
    f1_y1 = sigma_theta_star(exp(y(7)),index_star,index_end,data);
    f2_y1 = dlogA_theta_star2(y(1),index_end,data);
%     f3_y1 = lambda_theta_star(y(1),exp(y(6)),exp(y(2)),...
%         mu_theta_star(exp(y(6)),n,data),A_theta_star(y(1),x1),exp(y(4)));
    f4_y1 = delta_theta_star(exp(y(7)),index_star,index_end,data);
    f5_y1 = rho_theta_star(exp(y(7)),index_star,index_end,data);
    
    sigma_theta_node = sigma_theta(exp(yt),index_star,index_end,data,nodes);
    rho_theta_node = rho_theta(exp(yt),index_star,index_end,data,nodes);
    mu_theta_node = mu_theta(exp(yt),index_star,index_end,data,nodes);
    lambda_theta_node = exp(lambda);
    
    num_A = 0; denom_A = 0;
    for j=1:length(nodes)
       num_A = num_A + weights(j)*lambda_theta_node(j)*...
           rho_theta_node(j)*(sigma_theta_node(j)-1)*double(nodes(j)>=y(1));
       denom_A = denom_A + weights(j)*lambda_theta_node(j)*double(nodes(j)>=y(1));
    end
    A_y1 = num_A/denom_A;
    
    num_B = 0; denom_B = 0;
    for j=1:length(nodes)
       num_B = num_B + weights(j)*lambda_theta_node(j)*(1-1/mu_theta_node(j))*...
           sigma_theta_node(j)*double(nodes(j)>=y(1));
       denom_B = denom_B + weights(j)*lambda_theta_node(j)*(1-1/mu_theta_node(j))*double(nodes(j)>=y(1));
    end
    B_y1 = num_B/denom_B;
    
    num_C = 0; denom_C = 0;
    for j=1:length(nodes)
       num_C = num_C + weights(j)*lambda_theta_node(j)*(rho_theta_node(j)-1)*double(nodes(j)>=y(1));
       denom_C = denom_C + weights(j)*lambda_theta_node(j)*double(nodes(j)>=y(1));
    end
    C_y1 = num_C/denom_C;
    
%     D_theta = 1-rho_theta_node;
    E_theta = rho_theta_node.*(sigma_theta_node-1);
    G_theta = rho_theta_node.*sigma_theta_node;
%     G_theta_star = rho_theta_star(exp(y(6)),n,data)*f1_y1;
    f6_y1 = f5_y1*(f1_y1-1)-A_y1;
    
    Nnode = length(nodes);
    
    % system of ODE
    % ydot(1) = 1/((f1_y1-1)*f2_y1)*(-f1_y1);
    M1 = [0, 0, -f1_y1/((f1_y1-1)*f2_y1), -1/((f1_y1-1)*f2_y1), 0, 0, 0, zeros(1,Nnode), zeros(1,Nnode)];
    M2 = [exp(y(6))/(1-y(1)), 0, -1-A_y1, -1, 0, 0, 0, zeros(1,Nnode), zeros(1,Nnode)]; 
    M3 = [0, 0, 0, -1/B_y1, 0, 0, 0, zeros(1,Nnode), zeros(1,Nnode)]; 
    M4 = [-(f4_y1-1)*exp(y(6))/(1-y(1)), exp(y(5))-1, C_y1, 0, 0, 0, 0, zeros(1,Nnode), zeros(1,Nnode)];
    M5 = [0, 0, 1, 1, 0, 0, 0, zeros(1,Nnode), zeros(1,Nnode)]; 
    M6 = [(exp(y(6))-1)/(1-y(1))+f6_y1*f2_y1, 0, f6_y1, 0, 0, 0, 0, zeros(1,Nnode), zeros(1,Nnode)]; 
    M7 = [f1_y1*f2_y1*f5_y1, 0, f1_y1*f5_y1, 0, 0, 0, 0, zeros(1,Nnode), zeros(1,Nnode)]; 
%     M5 = [zeros(Nnode,1), zeros(Nnode,1), D_theta', zeros(Nnode,1), ...
%         zeros(Nnode,2*Nnode), zeros(Nnode,1), zeros(Nnode,Nnode), zeros(Nnode,1)]; 
    M8 = [ones(Nnode,1)*(exp(y(6))-1)/(1-y(1)), zeros(Nnode,1), E_theta'-ones(Nnode,1)*A_y1, zeros(Nnode,1), ...
        zeros(Nnode,1), zeros(Nnode,1), zeros(Nnode,1), zeros(Nnode,Nnode), zeros(Nnode,Nnode)];
    M9 = [zeros(Nnode,1), zeros(Nnode,1), G_theta', zeros(Nnode,1), ...
        zeros(Nnode,1), zeros(Nnode,1), zeros(Nnode,1), zeros(Nnode,Nnode), zeros(Nnode,Nnode)];
%     Mstar = [0, 0, G_theta_star, 0, 0, zeros(1,Nnode), 0]; 
    M = [M1 ; M2 ; M3 ; M4 ; M5 ; M6 ; M7 ; M8 ; M9];
    V = [-1/((f1_y1-1)*f2_y1); 0; -1/B_y1; 0; 0; 0; 0; zeros(Nnode,1); zeros(Nnode,1)];
    
    N_all = 4+3+Nnode*2;
    
    % output
    ydot_all = inv(eye(N_all)-M)*V;
    
    ydot = ydot_all(8:Nnode+7)';
    
%     ydot(1) = ydot_all(1); % \theta^*
%     ydot(2) = ydot_all(2); % \logM
%     ydot(3) = ydot_all(3); % \logP
%     ydot(4) = ydot_all(4); % \logY
%     ydot(5) = ydot_all(4+2*Nnode+1); % \log(\bar{\delta})
%     ydot(6) = ydot_all(end); % \log(\frac{y_{\theta^*}}{Y})

end