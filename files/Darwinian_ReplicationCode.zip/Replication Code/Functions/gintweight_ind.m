
function intg = gintweight_ind(lambda,x,nodes,weights,theta_star)
    num = 0;
    denom = 0;
    for j=1:length(nodes)
        num = num + weights(j)*lambda(j)*x(j)*double(nodes(j)>=theta_star);
        denom = denom + weights(j)*lambda(j)*double(nodes(j)>=theta_star);
    end
    intg = num/denom;

end