function yp=rk4step_vp_fr(y,index_star,index_end,hL,lambda,yt,vp,mu,tau,data,nodes,weights,kappa,bound,ydot_vp_fr)
    %one step of the Runge-Kutta order 4 method
    
    s1 = ydot_vp_fr(y,index_star,index_end,lambda,yt,vp,mu,tau,data,nodes,weights,kappa,bound);
    s2 = ydot_vp_fr(y,index_star,index_end,lambda,yt,vp+hL*s1/2,mu,tau,data,nodes,weights,kappa,bound);
    s3 = ydot_vp_fr(y,index_star,index_end,lambda,yt,vp+hL*s2/2,mu,tau,data,nodes,weights,kappa,bound);
    s4 = ydot_vp_fr(y,index_star,index_end,lambda,yt,vp+hL*s3,mu,tau,data,nodes,weights,kappa,bound);
    yp = vp+hL*(s1+2*s2+2*s3+s4)/6;
end