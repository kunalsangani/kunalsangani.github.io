
function dlogA_theta = dlogA_theta_star2(theta_star,index_end,data)
    % mapping from theta_star to dlogA_theta_star (f2(y(1)))
    
    % y(1) = \theta^*, y(2) = \logM, y(3) = d\logP, y(4) = d\logY
    % y(5) = \log(\bar{\delta}), y(6) = \log(\lambda_{\theta^*})
    % y(7) = \log(\frac{y_{\theta^*}}{Y})
    % lambda=\lambda_\theta, yt=log(\frac{y_\theta}{Y})
    % data = [ytheta', Upsdata', mudata', sigmadata', rhodata', deltadata',lambdadata',Prod'];
    
    Prod = data(:,8)';
    h=0.0001;
    dlogA = 1./Prod(2:end).*(diff(Prod)/h);

    index = floor(index_end*theta_star)+1;
    
    if index < index_end-1
        dlogA_theta = dlogA(index);
    else
        dlogA_theta = dlogA(index_end-1);
    end
    
%     for j=1:n-2
%         if (ytheta(j)<y_theta_star && y_theta_star<ytheta(j+1)) || y_theta_star == ytheta(j) 
%             index = j;
%         elseif y_theta_star < ytheta(1)
%             index = 1;
%         elseif y_theta_star > ytheta(n-1)
%             index = n-1;
%         end
%     end
%     delta_theta = data(index,6);

end