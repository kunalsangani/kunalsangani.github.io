function yp=rk4step_yt_fr(y,index_star,index_end,hL,lambda,yt,vp,mu,tau,data,nodes,weights,kappa,bound,ydot_yt_fr)
    %one step of the Runge-Kutta order 4 method
    
    s1 = ydot_yt_fr(y,index_star,index_end,lambda,yt,vp,mu,tau,data,nodes,weights,kappa,bound);
    s2 = ydot_yt_fr(y,index_star,index_end,lambda,yt+hL*s1/2,vp,mu,tau,data,nodes,weights,kappa,bound);
    s3 = ydot_yt_fr(y,index_star,index_end,lambda,yt+hL*s2/2,vp,mu,tau,data,nodes,weights,kappa,bound);
    s4 = ydot_yt_fr(y,index_star,index_end,lambda,yt+hL*s3,vp,mu,tau,data,nodes,weights,kappa,bound);
    yp = yt+hL*(s1+2*s2+2*s3+s4)/6;
end