
function z=ydot3(w,a,b)
    z = a*b-a*w;
end