
function ydot = ydot_fr_hom(y,index_star,index_end,data,kappa)

    % y(1) = \log(M), y(2) = \log(P), y(3) = \log(Y)
    % y(4) = \log(\delta), y(5) = \log(\Lambda_L)
    % y(6) = \log(\lambda)
    % y(7) = \log(\frac{y}{Y})
    % y(8) = \log(Variable Profit)
    % y(9) = \log(\mu), y(10) = \log(\tau)

    % data = [ytheta', Upsdata', mudata', sigmadata', rhodata', deltadata',lambdadata',Prod'];
     
    % define auxiliary variables
%     f1_y1 = sigma_theta_star(exp(y(8)),index_star,index_end,data);
%     f2_y1 = dlogA_theta_star2(y(1),index_end,data);
%     f3_y1 = lambda_theta_star(y(1),exp(y(6)),exp(y(2)),...
%         mu_theta_star(exp(y(6)),n,data),A_theta_star(y(1),x1),exp(y(4)));
%     f4_y1 = delta_theta_star(exp(y(8)),index_star,index_end,data);
%     f5_y1 = rho_theta_star(exp(y(8)),index_star,index_end,data);
%     f6_y1 = mu_A_elas(y,mu,index_star,index_end,nodes,data);
%     f7_y1 = tau_A_elas(y,tau,index_star,index_end,nodes,data);
    
%     A_theta_node = A_theta(y(1),x1,nodes);
    sigma_theta_node = sigma_theta_hom(exp(y(7)),index_star,index_end,data);
%     rho_theta_node = rho_theta(exp(yt),index_star,index_end,data,nodes);
%     mu_theta_node = mu_theta(exp(yt),index_star,index_end,data,nodes);
%     lambda_theta_node = exp(lambda);
%     mu_theta_node = exp(mu);
%     vp_theta_node = exp(vp);
%     tau_theta_node = exp(tau);
%     delta_theta_node = delta_theta(exp(yt),index_star,index_end,data,nodes);
%    lambda_theta_node = lambda_theta(y(1),exp(yt),exp(y(2)),...
%        mu_theta_node,A_theta_node,exp(y(4)));
    
%     A_y1 = 0; B_y1 = 0; B1_y1 = 0; B2_y1 = 0; B3_y1 = 0; B4_y1 = 0; 
%     C_y1 = 0; D_y1 = 0; E_y1 = 0; F_y1 = 0; G_y1 = 0;
%     for j=1:length(nodes)
%         A_y1 = A_y1 + weights(j)*lambda_theta_node(j)*(sigma_theta_node(j)-1)*...
%             double(nodes(j)>=y(1))/(1-y(1));
%         B_y1 = B_y1 + weights(j)*lambda_theta_node(j)*(sigma_theta_node(j)-1)*...
%             (-kappa(1)*(log(mu_theta_node(j))-log(delta_theta_node(j)))-kappa(2)*(log(tau_theta_node(j))-log(1/delta_theta_node(j))))*...
%             double(nodes(j)>=y(1))/(1-y(1));
%         B1_y1 = B1_y1 + weights(j)*vp_theta_node(j)*...
%             double(nodes(j)>=y(1))/(1-y(1));
%         B2_y1 = B2_y1 + weights(j)*vp_theta_node(j)*sigma_theta_node(j)*...
%             double(nodes(j)>=y(1))/(1-y(1));
%         B3_y1 = B3_y1 + weights(j)*vp_theta_node(j)*sigma_theta_node(j)*...
%             ((-kappa(2))*(log(tau_theta_node(j))-log(1/delta_theta_node(j))))*...
%             double(nodes(j)>=y(1))/(1-y(1));
%         B4_y1 = B4_y1 + weights(j)*vp_theta_node(j)*...
%             (1/(mu_theta_node(j)-1)-(sigma_theta_node(j)-1))*...
%             ((-kappa(1))*(log(mu_theta_node(j))-log(delta_theta_node(j))))*...
%             double(nodes(j)>=y(1))/(1-y(1));
%         C_y1 = C_y1 + weights(j)*lambda_theta_node(j)*...
%             double(nodes(j)>=y(1))/(1-y(1));
%         D_y1 = D_y1 + weights(j)*lambda_theta_node(j)*...
%             (-kappa(1)*(log(mu_theta_node(j))-log(delta_theta_node(j)))-kappa(2)*(log(tau_theta_node(j))-log(1/delta_theta_node(j))))*...
%             double(nodes(j)>=y(1))/(1-y(1));
%         E_y1 = E_y1 + weights(j)*lambda_theta_node(j)/tau_theta_node(j)*...
%             double(nodes(j)>=y(1))/(1-y(1));
%         F_y1 = F_y1 + weights(j)*lambda_theta_node(j)/tau_theta_node(j)*sigma_theta_node(j)*...
%             double(nodes(j)>=y(1))/(1-y(1));
%         G_y1 = G_y1 + weights(j)*lambda_theta_node(j)/tau_theta_node(j)*...
%             ((sigma_theta_node(j)-1)*(-kappa(1))*(log(mu_theta_node(j))-log(delta_theta_node(j)))+...
%             sigma_theta_node(j)*(-kappa(2))*(log(tau_theta_node(j))-log(1/delta_theta_node(j))))*...
%             double(nodes(j)>=y(1))/(1-y(1));
%     end

    A = sigma_theta_node;
%     I_theta = delta_theta_node;
    
    
    % system of ODE

    M1 = [0, 0, 0, 0, 0, 0, 0, 1, 0, 0];
    M2 = [-1/A, 0, -1/A, 0, (A-1)/A, 0, 0, 0, (A-1)/A, (A-1)/A]; 
    M3 = [exp(y(4))-1, 0, 0, 0, -1, 0, 0, 0, -1, -1]; 
    M4 = [0, 1, 1, 0, 0, 0, 0, 0, 0, 0]; 
    M5 = [0, 0, 0, 0, 0, 1, 0, 0, 0, -1]; 
    M6 = [1, A, 1, 0, 1-A, 0, 0, 0, 1-A, 1-A]; 
    M7 = [0, A, 0, 0, -A, 0, 0, 0, -A, -A]; 
    M8 = [0, 0, 0, 0, -1, 1, 0, 0, 1/(exp(y(9))-1), -1]; 
    M9 = [0, 0, 0, 0, 0, 0, 0, 0, 0, 0]; 
    M10 = [0, 0, 0, 0, 0, 0, 0, 0, 0, 0]; 
    
%     Mstar = [0, 0, G_theta_star, 0, 0, zeros(1,Nnode), 0]; 
    M = [M1 ; M2 ; M3 ; M4 ; M5 ; M6 ; M7 ; M8 ; M9 ; M10];
    V = [0; 0; 0; 0; 0; 0; 0; 0; ...
        -kappa(1)*(y(9)-y(4)); -kappa(2)*(y(10)+y(4))];
    
        
    N_all = 10; % theta_star is constant, not variable
    
    % output
    ydot_all = inv(eye(N_all)-M)*V;

    
    ydot(1) = ydot_all(1); % \logM
    ydot(2) = ydot_all(2); % \logP
    ydot(3) = ydot_all(3); % \logY
    ydot(4) = ydot_all(4); % \log(\delta)
    ydot(5) = ydot_all(5); % \log(\Lambda_L)
    ydot(6) = ydot_all(6); % \log(\lambda)
    ydot(7) = ydot_all(7); % \log(\frac{y}{Y})
    ydot(8) = ydot_all(8); % \log(Varible Profit)
    ydot(9) = ydot_all(9); % \log(\mu)
    ydot(10) = ydot_all(10); % \log(\tau)
    
    
end