Replication code for "The Darwinian Returns to Scale" by David Baqaee, Emmanuel Farhi, and Kunal Sangani.

- main_fitting.m fits smooth curves to pass-through estimates from Amiti et al (2019) and the sales distribution from Belgian VAT data.
- driver.py generates all tables and figures in the paper and appendices. 
- support_functions.py and klenow_willis.py provide additional functions that are used in driver.py
- ODE_Store caches solutions to the non-parametric calibration approach for various values of the boundary conditions. When the solution has already been generated and is stored in ODE_Store, support_functions.py will use the saved version. Clear the cache in ODE_Store to regenerate all calibrations.