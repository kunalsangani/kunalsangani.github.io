import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
import tikzplotlib
import os
import support_functions as sp 
import klenow_willis as kw
from scipy.interpolate import interp1d
import matplotlib
import statsmodels.formula.api as smf
import statsmodels.api as sm
from statsmodels.iolib.summary2 import summary_col
from scipy.optimize import root
from scipy.interpolate import interp1d

matplotlib.rcParams['font.family'] = "Palatino"
matplotlib.rcParams['font.sans-serif'] = "Palatino"
matplotlib.rcParams['mathtext.fontset'] = 'cm'
matplotlib.rcParams.update({'font.size': 16})
matplotlib.rcParams.update({'text.usetex': False})

matplotlib.rcParams['axes.prop_cycle'] = matplotlib.cycler(
	color=[	[0, 0.4470, 0.7410], [0.8500, 0.3250, 0.0980], [0.9290, 0.6940, 0.1250], [0.4940, 0.1840, 0.5560], [0.4660, 0.6740, 0.1880], [0.3010, 0.7450, 0.9330], [0.6350, 0.0780, 0.1840]]
) 

def plot_all_variables(mu_bar, effselection, delta_bar, theta_star, product=False, saveprefix=None):
	rho,shares,mu,A,delta = sp.generate_all_variables(mu_bar, effselection=effselection, delta_bar=delta_bar)
	if product:
		rho,shares,mu,A,delta = sp.generate_all_variables_product(mu_bar, effselection=effselection, delta_bar=delta_bar)
	pctl = np.linspace(theta_star,1,len(rho))
	p = mu/A
	relative_y = shares/p 
	# Pass-throughs
	plt.figure()
	plt.plot(pctl, rho)
	plt.xlabel('Percentile')
	plt.ylabel('Pass-through, $\\rho_\\theta$')
	plt.xlim([theta_star, 1])
	plt.ylim([rho.min(), 1])
	plt.tight_layout()
	if saveprefix is not None:
		plt.gcf().savefig(saveprefix + 'rho.pdf', dpi=300, bbox_inches='tight')
	# Sales shares
	plt.figure()
	plt.plot(pctl, np.log(shares))
	plt.xlabel('Percentile')
	plt.ylabel('Log sales density, $\\log \\lambda_\\theta$')
	plt.xlim([theta_star, 1])
	plt.ylim([np.log(shares).min(), np.log(shares).max()])
	plt.tight_layout()
	if saveprefix is not None:
		plt.gcf().savefig(saveprefix + 'lambda.pdf', dpi=300, bbox_inches='tight')
	# Productivity
	plt.figure()
	plt.plot(pctl, np.log(A))
	plt.xlabel('Percentile')
	plt.ylabel('Log productivity/quality, $\\log(A_\\theta B_\\theta)$')
	plt.xlim([theta_star, 1])
	plt.ylim([np.log(A).min(), np.log(A).max()])
	plt.tight_layout()
	if saveprefix is not None:
		plt.gcf().savefig(saveprefix + 'A.pdf', dpi=300, bbox_inches='tight')
	# Productivity - not tight
	plt.figure()
	plt.plot(pctl, np.log(A))
	plt.xlabel('Percentile')
	plt.ylabel('Log productivity/quality, $\\log(A_\\theta B_\\theta)$')
	plt.tight_layout()
	if saveprefix is not None:
		plt.gcf().savefig(saveprefix + 'A.pdf', dpi=300, bbox_inches='tight')
	# Productivity vs. sales
	plt.figure()
	plt.plot(np.log(shares), np.log(A))
	plt.xlabel('Log sales density, $\\log \\lambda_\\theta$')
	plt.ylabel('Log productivity/quality, $\\log(A_\\theta B_\\theta)$')
	plt.xlim([np.log(shares).min(), np.log(shares).max()])
	plt.ylim([np.log(A).min(), np.log(A).max()])
	plt.tight_layout()
	if saveprefix is not None:
		plt.gcf().savefig(saveprefix + 'A_vs_sales.pdf', dpi=300, bbox_inches='tight')
	# Productivity vs. sales - not tight
	plt.figure()
	plt.plot(np.log(shares), np.log(A))
	plt.xlabel('Log sales density, $\\log \\lambda_\\theta$')
	plt.ylabel('Log productivity/quality, $\\log(A_\\theta B_\\theta)$')
	plt.tight_layout()
	if saveprefix is not None:
		plt.gcf().savefig(saveprefix + 'A_vs_sales_nocrop.pdf', dpi=300, bbox_inches='tight')
	# Markups
	plt.figure()
	plt.plot(np.log(A), mu)
	plt.xlabel('Log productivity/quality, $\\log(A_\\theta B_\\theta)$')
	plt.ylabel('Markup, $\\mu_\\theta$')
	plt.xlim([np.log(A).min(), np.log(A).max()])
	plt.ylim([1, mu.max()])
	plt.tight_layout()
	if saveprefix is not None:
		plt.gcf().savefig(saveprefix + 'mu.pdf', dpi=300, bbox_inches='tight')
	# Markups - not tight
	plt.figure()
	plt.plot(np.log(A), mu)
	plt.xlabel('Log productivity/quality, $\\log(A_\\theta B_\\theta)$')
	plt.ylabel('Markup, $\\mu_\\theta$')
	plt.tight_layout()
	if saveprefix is not None:
		plt.gcf().savefig(saveprefix + 'mu_nocrop.pdf', dpi=300, bbox_inches='tight')
	# Consumer surplus ratios
	plt.figure()
	plt.plot(np.log(A), delta)
	plt.xlabel('Log productivity/quality, $\\log(A_\\theta B_\\theta)$')
	plt.ylabel('Consumer surplus ratio, $\\delta_\\theta$')
	plt.xlim([np.log(A).min(), np.log(A).max()])
	plt.ylim([1, delta.max()])
	plt.tight_layout()
	if saveprefix is not None:
		plt.gcf().savefig(saveprefix + 'delta.pdf', dpi=300, bbox_inches='tight')
	# Consumer surplus ratios - not tight
	plt.figure()
	plt.plot(np.log(A), delta)
	plt.xlabel('Log productivity/quality, $\\log(A_\\theta B_\\theta)$')
	plt.ylabel('Consumer surplus ratio, $\\delta_\\theta$')
	plt.tight_layout()
	if saveprefix is not None:
		plt.gcf().savefig(saveprefix + 'delta_nocrop.pdf', dpi=300, bbox_inches='tight')
	# Demand curve
	plt.figure()
	plt.plot(relative_y, p)
	plt.xlabel('Per-capita quantity, $y_\\theta$')
	plt.ylabel('Relative price, $(1/B_\\theta) p_\\theta / P$')
	plt.xlim([relative_y.min(), relative_y.max()])
	plt.ylim([p.min(), p.max()])
	plt.tight_layout()
	if saveprefix is not None:
		plt.gcf().savefig(saveprefix + 'demandcurve.pdf', dpi=300, bbox_inches='tight')
	# Log-log demand curve
	plt.figure()
	plt.plot(np.log(relative_y), np.log(p))
	plt.xlabel('Log per-capita quantity, $\\log(y_\\theta)$')
	plt.ylabel('Log relative price, $\\log ( (1/B_\\theta) p_\\theta / P)$')
	plt.xlim([np.log(relative_y).min(), np.log(relative_y).max()])
	plt.ylim([np.log(p).min(), np.log(p).max()])
	plt.tight_layout()
	if saveprefix is not None:
		plt.gcf().savefig(saveprefix + 'loglogdemandcurve.pdf', dpi=300, bbox_inches='tight')

def generate_HSA_results(mu_bar, effselection, delta_bar, theta_star, product=False):
	rho,shares,mu,A,delta = sp.generate_all_variables(mu_bar, effselection=effselection, delta_bar=delta_bar)
	if product:
		rho,shares,mu,A,delta = sp.generate_all_variables_product(mu_bar, effselection=effselection, delta_bar=delta_bar)
	shares = shares/shares.sum() * (1-theta_star)
	delta_bar = sp.weighted_exp(delta, shares)
	elast = mu/(mu - 1)
	theta = np.linspace(theta_star, 1, len(mu))
	h = np.diff(np.linspace(0, 1, len(mu)))[0]
	# Change in variable profits at selection cutoff, entry/overhead costs
	gammastar = 1/((1-theta_star) * (-elast[0]/rho[0] * np.diff(np.log(mu))[0]/h + (elast[0]/rho[0] - 1)*np.diff(np.log(A))[0]/h))
	overhead_cost = 1/(1 - theta_star) * shares[0] * (1 - 1/mu[0])
	entry_cost = sp.weighted_exp(1 - 1/mu, shares) - (1 - theta_star)*overhead_cost
	entry_cost_share = entry_cost/(entry_cost + (1-theta_star)*overhead_cost)
	# Create allocative efficiency margins variables
	xi_epsilon = (delta_bar - 1) * sp.weighted_cov(elast, 1/mu, shares)
	xi_thetastar = (delta_bar - delta[0])*gammastar*(sp.weighted_exp(elast[0]/elast, shares) - 1)*len(shares)*shares[0]/(1-theta_star)
	xi_mu = sp.weighted_exp(1/elast, shares) * sp.weighted_exp((1-rho)*elast*(1 - delta_bar / mu), shares)
	zeta_epsilon = (mu_bar - 1) * sp.weighted_cov(elast, 1/mu, shares)
	zeta_thetastar = gammastar*(mu_bar / mu[0] - 1)*(sp.weighted_exp(elast[0]/elast, shares) - 1)*len(shares)*shares[0]/(1-theta_star)
	zeta_mu = -(mu_bar - 1) * sp.weighted_exp((elast - 1)*(1 - rho), shares) * sp.weighted_exp(1/elast, shares)
	# Baseline results (heterogeneous firms)
	darwinian = mu_bar * xi_epsilon
	selection = mu_bar * xi_thetastar
	procompetitive = mu_bar * xi_mu 
	allocative_efficiency = darwinian +selection + procompetitive
	technical_efficiency = delta_bar - 1
	dlogY = technical_efficiency + allocative_efficiency
	dlogQ = sp.weighted_exp(1-rho, shares) * sp.weighted_exp(1/elast, shares) * mu_bar 
	dlogmu_bar = mu_bar*(zeta_epsilon + zeta_thetastar + zeta_mu)
	# Homogeneous firms results
	allocative_eff_homog = mu_bar * (1-sp.weighted_exp(rho, shares)) * (1 - delta_bar / mu_bar)
	technical_eff_homog = delta_bar - 1
	dlogY_homog = technical_eff_homog + allocative_eff_homog
	dlogQ_homog = sp.weighted_exp(1-rho, shares)*(mu_bar - 1)
	dlogmu_bar_homog = -mu_bar*(mu_bar - 1)*(1/mu_bar)*sp.weighted_exp(1-rho, shares)
	# Entry tax results
	darwinian_entrytax = (1 - delta_bar/mu_bar - xi_epsilon)*entry_cost_share
	selection_entrytax = -(xi_thetastar + (delta_bar-delta[0])*shares[0]*gammastar*len(shares))*entry_cost_share
	procompetitive_entrytax = -xi_mu*entry_cost_share
	dlogY_entrytax = darwinian_entrytax + selection_entrytax + procompetitive_entrytax
	dlogY_entrytax_homog = (1 - delta_bar/mu_bar)*sp.weighted_exp(rho, shares)*entry_cost_share
	# Assemble results into arrays
	results_baseline = np.array([dlogY, technical_efficiency, allocative_efficiency, darwinian, selection, procompetitive, dlogQ, dlogmu_bar])
	results_homog = np.array([dlogY_homog, technical_eff_homog, allocative_eff_homog, dlogQ_homog, dlogmu_bar_homog])
	results_entrytax = np.array([dlogY_entrytax, darwinian_entrytax, selection_entrytax, procompetitive_entrytax, dlogY_entrytax_homog])
	return results_baseline,results_homog,results_entrytax

def generate_HSA_results_homog(mu_bar, delta_bar, product=False):
	rho,shares,mu,A,delta = sp.generate_all_variables(mu_bar, effselection=True, delta_bar=mu_bar)
	if product:
		rho,shares,mu,A,delta = sp.generate_all_variables_product(mu_bar, effselection=True, delta_bar=mu_bar)
	allocative_eff_homog = mu_bar * (1-sp.weighted_exp(rho, shares)) * (1 - delta_bar / mu_bar)
	technical_eff_homog = delta_bar - 1
	dlogY_homog = technical_eff_homog + allocative_eff_homog
	dlogQ_homog = sp.weighted_exp(1-rho, shares)*(mu_bar - 1)
	dlogmu_bar_homog = -mu_bar*(mu_bar - 1)*(1/mu_bar)*sp.weighted_exp(1-rho, shares)
	return np.array([dlogY_homog, technical_eff_homog, allocative_eff_homog, dlogQ_homog, dlogmu_bar_homog])

def generate_Kimball_results_homog(mu_bar, delta_bar):
	rho,shares,mu,A,delta = sp.generate_all_variables(mu_bar, effselection=True, delta_bar=mu_bar)
	xi_mu_homog = (1-sp.weighted_exp(rho, shares)) * (1 - delta_bar / mu_bar)
	allocative_eff_homog = delta_bar * xi_mu_homog/(1-xi_mu_homog)
	technical_eff_homog = delta_bar - 1
	dlogY_homog = technical_eff_homog + allocative_eff_homog
	dlogQ_homog = sp.weighted_exp(1-rho, shares)*(mu_bar - 1)
	# Assemble results into arrays
	results_baseline = np.array([dlogY, technical_efficiency, allocative_efficiency, darwinian, selection, procompetitive, dlogQ])
	results_homog = np.array([dlogY_homog, technical_eff_homog, allocative_eff_homog, dlogQ_homog])
	return results_baseline,results_homog


def generate_HSA_results_cutoff(mu_bar, delta_cutoff, theta_star):
	rho,shares,mu,A,delta = sp.generate_all_variables_deltacutoff(mu_bar, delta_cutoff=delta_cutoff)
	shares = shares/shares.sum() * (1-theta_star)
	delta_bar = sp.weighted_exp(delta, shares)
	elast = mu/(mu - 1)
	theta = np.linspace(theta_star, 1, len(mu))
	h = np.diff(np.linspace(0, 1, len(mu)))[0]
	# Change in variable profits at selection cutoff, entry/overhead costs
	gammastar = 1/((1-theta_star) * (-elast[0]/rho[0] * np.diff(np.log(mu))[0]/h + (elast[0]/rho[0] - 1)*np.diff(np.log(A))[0]/h))
	# Create allocative efficiency margins variables
	xi_epsilon = (delta_bar - 1) * sp.weighted_cov(elast, 1/mu, shares)
	xi_thetastar = (delta_bar - delta[0])*gammastar*(sp.weighted_exp(elast[0]/elast, shares) - 1)*len(shares)*shares[0]/(1-theta_star)
	xi_mu = sp.weighted_exp(1/elast, shares) * sp.weighted_exp((1-rho)*elast*(1 - delta_bar / mu), shares)
	# Baseline results (heterogeneous firms)
	darwinian = mu_bar * xi_epsilon
	selection = mu_bar * xi_thetastar
	procompetitive = mu_bar * xi_mu 
	allocative_efficiency = darwinian +selection + procompetitive
	technical_efficiency = delta_bar - 1
	dlogY = technical_efficiency + allocative_efficiency
	return dlogY, technical_efficiency, allocative_efficiency, darwinian, selection, procompetitive, delta_bar

def generate_HSA_change_in_TFPR_dispersion(mu_bar, effselection, delta_bar, theta_star, product=False):
	rho,shares,mu,A,delta = sp.generate_all_variables(mu_bar, effselection=effselection, delta_bar=delta_bar)
	if product:
		rho,shares,mu,A,delta = sp.generate_all_variables_product(mu_bar, effselection=effselection, delta_bar=delta_bar)
	shares = shares/shares.sum() * (1-theta_star)
	delta_bar = sp.weighted_exp(delta, shares)
	elast = mu/(mu - 1)
	theta = np.linspace(theta_star, 1, len(mu))
	h = np.diff(np.linspace(0, 1, len(mu)))[0]
	# Change in variable profits at selection cutoff, entry/overhead costs
	gammastar = 1/((1-theta_star) * (-elast[0]/rho[0] * np.diff(np.log(mu))[0]/h + (elast[0]/rho[0] - 1)*np.diff(np.log(A))[0]/h))
	cutoff_share = len(shares)*shares[0]/(1-theta_star)
	Var_log_TFPR = sp.weighted_cov(np.log(mu), np.log(mu), shares)
	E_log_TFPR = sp.weighted_exp(np.log(mu), shares)
	extensive_margin = mu_bar * gammastar * cutoff_share * (sp.weighted_exp(elast[0]/elast, shares) - 1)
	extensive_margin = extensive_margin*(Var_log_TFPR + E_log_TFPR*(np.log(mu[0]) - cutoff_share*E_log_TFPR) + np.log(mu[0])*(E_log_TFPR - cutoff_share*np.log(mu[0])))
	intensive_margin = -sp.weighted_cov(mu_bar/(mu**2), rho*(elast-1), shares) + 2*sp.weighted_cov(1/mu, rho*(elast-1), shares) - 2*sp.weighted_cov(mu_bar/mu, rho, shares)
	intensive_margin = intensive_margin*sp.weighted_exp(1/elast, shares)
	intensive_margin = -sp.weighted_cov(mu_bar/(mu**2), (elast-1), shares) + 2*sp.weighted_cov(1/mu, (elast-1), shares)
	intensive_margin = intensive_margin*sp.weighted_exp(1/elast, shares)



def generate_Kimball_results(mu_bar, effselection, delta_bar, theta_star):
	rho,shares,mu,A,delta = sp.generate_all_variables(mu_bar, effselection=effselection, delta_bar=delta_bar)
	shares = shares/shares.sum() * (1-theta_star)
	delta_bar = sp.weighted_exp(delta, shares)
	elast = mu/(mu - 1)
	theta = np.linspace(theta_star, 1, len(mu))
	h = np.diff(np.linspace(0, 1, len(mu)))[0]
	# Change in variable profits at selection cutoff, entry/overhead costs
	gammastar = 1/((1-theta_star) * (-elast[0]/rho[0] * np.diff(np.log(mu))[0]/h + (elast[0]/rho[0] - 1)*np.diff(np.log(A))[0]/h))
	overhead_cost = 1/(1 - theta_star) * shares[0] * (1 - 1/mu[0])
	entry_cost = sp.weighted_exp(1 - 1/mu, shares) - (1 - theta_star)*overhead_cost
	entry_cost_share = entry_cost/(entry_cost + (1-theta_star)*overhead_cost)
	# Create allocative efficiency margins variables
	xi_epsilon = (delta_bar - 1) * sp.weighted_cov(elast, 1/mu, shares)
	xi_thetastar = (delta_bar - delta[0])*gammastar*(sp.weighted_exp(elast[0]/elast, shares) - 1)*len(shares)*shares[0]/(1-theta_star)
	xi_mu = sp.weighted_exp(1/elast, shares) * sp.weighted_exp((1-rho)*elast*(1 - delta_bar / mu), shares)
	# Baseline results (heterogeneous firms)
	darwinian = delta_bar * xi_epsilon/(1 - xi_epsilon)
	selection = delta_bar * (xi_epsilon+xi_thetastar)/(1-xi_epsilon-xi_thetastar) - darwinian
	procompetitive = delta_bar * (xi_epsilon+xi_thetastar+xi_mu)/(1-xi_epsilon-xi_thetastar-xi_mu) - selection - darwinian
	allocative_efficiency = darwinian + selection + procompetitive
	technical_efficiency = delta_bar - 1
	dlogY = technical_efficiency + allocative_efficiency
	dlogQ = sp.weighted_exp(1-rho, shares) * sp.weighted_exp(1/elast, shares) * (dlogY + 1) 
	# Homogeneous firms results
	xi_mu_homog = (1-sp.weighted_exp(rho, shares)) * (1 - delta_bar / mu_bar)
	allocative_eff_homog = delta_bar * xi_mu_homog/(1-xi_mu_homog)
	technical_eff_homog = delta_bar - 1
	dlogY_homog = technical_eff_homog + allocative_eff_homog
	dlogQ_homog = sp.weighted_exp(1-rho, shares)*(mu_bar - 1)
	# Assemble results into arrays
	results_baseline = np.array([dlogY, technical_efficiency, allocative_efficiency, darwinian, selection, procompetitive, dlogQ])
	results_homog = np.array([dlogY_homog, technical_eff_homog, allocative_eff_homog, dlogQ_homog])
	return results_baseline,results_homog

def klenow_willis_results(theta_star, plot=False, saveprefix=None):
	shares,delta,mu,rho,A = kw.generate_kw_distributions(N_firms=10000)
	delta_bar = sp.weighted_exp(delta, shares)
	elast = mu/(mu - 1)
	theta = np.linspace(theta_star, 1, len(mu))
	h = np.diff(np.linspace(0, 1, len(mu)))[0]
	# Plot results
	if plot:
		pctl = np.linspace(0, 1, len(mu))
		plt.figure()
		plt.plot(pctl, rho)
		plt.xlabel('Percentile')
		plt.ylabel('Pass-through, $\\rho_\\theta$')
		plt.ylim([0.2, 1])
		plt.tight_layout()
		if saveprefix is not None:
			plt.gcf().savefig(saveprefix + 'kw_rho.pdf', dpi=300, bbox_inches='tight')
		plt.figure()
		plt.plot(pctl, np.log(shares))
		plt.xlabel('Percentile')
		plt.ylabel('Log sales share, $\\lambda_\\theta$')
		plt.tight_layout()
		if saveprefix is not None:
			plt.gcf().savefig(saveprefix + 'kw_lambda.pdf', dpi=300, bbox_inches='tight')
	# Change in variable profits at selection cutoff, entry/overhead costs
	gammastar = 1/((1-theta_star) * (-elast[0]/rho[0] * np.diff(np.log(mu))[0]/h + (elast[0]/rho[0] - 1)*np.diff(np.log(A))[0]/h))
	overhead_cost = 1/(1 - theta_star) * shares[0] * (1 - 1/mu[0])
	entry_cost = sp.weighted_exp(1 - 1/mu, shares) - (1 - theta_star)*overhead_cost
	entry_cost_share = entry_cost/(entry_cost + (1-theta_star)*overhead_cost)
	# Create allocative efficiency margins variables
	xi_epsilon = (delta_bar - 1) * sp.weighted_cov(elast, 1/mu, shares)
	xi_thetastar = (delta_bar - delta[0])*shares[0]*gammastar*(sp.weighted_exp(elast[0]/elast, shares) - 1)
	xi_mu = sp.weighted_exp(1/elast, shares) * sp.weighted_exp((1-rho)*elast*(1 - delta_bar / mu), shares)
	# Baseline results (heterogeneous firms)
	darwinian = delta_bar * xi_epsilon/(1 - xi_epsilon)
	selection = delta_bar * (xi_epsilon+xi_thetastar)/(1-xi_epsilon-xi_thetastar) - darwinian
	procompetitive = delta_bar * (xi_epsilon+xi_thetastar+xi_mu)/(1-xi_epsilon-xi_thetastar-xi_mu) - selection - darwinian
	allocative_efficiency = darwinian + selection + procompetitive
	technical_efficiency = delta_bar - 1
	dlogY = technical_efficiency + allocative_efficiency
	dlogQ = sp.weighted_exp(1-rho, shares) * sp.weighted_exp(1/elast, shares) * (dlogY + 1) 
	# Assemble results into arrays
	results_baseline = np.array([dlogY, technical_efficiency, allocative_efficiency, darwinian, selection, procompetitive, dlogQ])
	return results_baseline

def boundary_condition_robustness():
	theta_star = 0.15
	mu_bar_range = np.arange(1.05, 1.155, 0.01)
	delta_cutoff_range = np.arange(1, 10.5, 1)
	dlogY = np.zeros((len(mu_bar_range), len(delta_cutoff_range)))
	technical_eff = np.zeros((len(mu_bar_range), len(delta_cutoff_range)))
	allocative_eff = np.zeros((len(mu_bar_range), len(delta_cutoff_range)))
	darwinian = np.zeros((len(mu_bar_range), len(delta_cutoff_range)))
	selection = np.zeros((len(mu_bar_range), len(delta_cutoff_range)))
	procompetitive = np.zeros((len(mu_bar_range), len(delta_cutoff_range)))
	delta_bar = np.zeros((len(mu_bar_range), len(delta_cutoff_range)))
	for i in range(len(mu_bar_range)):
		for j in range(len(delta_cutoff_range)):
			dlogY[i,j],technical_eff[i,j],allocative_eff[i,j],darwinian[i,j],selection[i,j],procompetitive[i,j],delta_bar[i,j] = generate_HSA_results_cutoff(mu_bar_range[i], delta_cutoff_range[j], theta_star)
	list_formatter = lambda x: '[' + ', '.join(["{:.3f}".format(a) for a in x]) + ']'
	Table9 = [[[dlogY[i,j],allocative_eff[i,j]] for j in range(len(delta_cutoff_range))] for i in range(len(mu_bar_range))]
	print('Table 9:')
	print(pd.DataFrame(Table9, index=mu_bar_range, columns=delta_cutoff_range.astype(int)).to_latex(formatters=[list_formatter]*len(delta_cutoff_range)))
	Table10_keep_cols = [0,2,4,6,8]
	Table10 = [[[darwinian[i,j],selection[i,j],procompetitive[i,j]] for j in Table10_keep_cols] for i in range(len(mu_bar_range))]
	print('Table 10:')
	print(pd.DataFrame(Table10, index=mu_bar_range, columns=delta_cutoff_range[Table10_keep_cols].astype(int)).to_latex(formatters=[list_formatter]*len(Table10_keep_cols)))

def nonlinear_results(mu_bar, effselection, delta_bar, theta_star):
	rho,shares,mu,A,delta = sp.generate_all_variables(mu_bar, effselection=effselection, delta_bar=delta_bar)
	shares = shares/shares.sum() * (1-theta_star)
	delta_bar = sp.weighted_exp(delta, shares)
	elast = mu/(mu - 1)
	theta = np.linspace(theta_star, 1, len(mu))
	p = mu/A
	p_P = p
	relative_y = shares/p 
	gammastar = 1/((1-theta_star) * (-elast[0]/rho[0] * np.diff(np.log(mu))[0]/np.diff(theta)[0] + (elast[0]/rho[0] - 1)*np.diff(np.log(A))[0]/np.diff(theta)[0]))
	rho_fn = interp1d(p, rho, fill_value=(rho[-1], 1), bounds_error=False)
	mu_fn = interp1d(p, mu, fill_value=(None, mu[0]), bounds_error=False)
	# Extending mu and rho above range were easy, because we could just use constant pass-through and same desired markup
	# To extend delta, we need to use an ODE
	# Note that d_delta = ((delta-1)(elast-1) - 1)*dlog(p/P)
	# Solving diffeq. yields delta = (delta_star - sigma/sigma-1)*(p/p_star)^(sigma-1) + sigma/sigma-1
	p_addl_range = np.linspace(1.2*p[0], p[0], 10000)[:-1]
	delta_addl_vals = (delta[0] - mu[0])*(p_addl_range/p[0])**(elast[0] - 1) + mu[0]
	delta_fn = interp1d(np.concatenate((p_addl_range, p)), np.concatenate((delta_addl_vals, delta)))
	# On each iteration, need to update all variables according to log-linearization
	STEP_SIZE = 0.005
	dlogL_max = 1
	dlogL_range = np.arange(0, dlogL_max + STEP_SIZE, STEP_SIZE)
	darwinian = np.zeros(len(dlogL_range))
	selection = np.zeros(len(dlogL_range))
	procompetitive = np.zeros(len(dlogL_range))
	technical_eff = np.zeros(len(dlogL_range))
	allocative_eff = np.zeros(len(dlogL_range))
	real_GDP = np.zeros(len(dlogL_range))
	sales_dist = np.zeros((len(dlogL_range), len(shares)))
	sales_dist[0,:] = shares/shares.sum()
	markup_dist = np.zeros((len(dlogL_range), len(mu)))
	markup_dist[0,:] = mu
	for i in range(1, len(dlogL_range)):
		# Calculate welfare effects
		xi_epsilon = (delta_bar - 1) * sp.weighted_cov(elast, 1/mu, shares)
		#xi_thetastar = (delta_bar - delta[0])*gammastar*(sp.weighted_exp(elast[0]/elast, shares) - 1)*len(shares)*shares[0]/(1-theta_star)
		xi_thetastar = (delta_bar - delta[0])*shares[0]*gammastar*(sp.weighted_exp(elast[0]/elast, shares) - 1)*len(shares)
		xi_mu = sp.weighted_exp(1/elast, shares) * sp.weighted_exp((1-rho)*elast*(1 - delta_bar / mu), shares)
		darwinian[i] = mu_bar * xi_epsilon * STEP_SIZE
		selection[i] = mu_bar * xi_thetastar * STEP_SIZE
		procompetitive[i] = mu_bar * xi_mu * STEP_SIZE
		allocative_eff[i] = darwinian[i] + selection[i] + procompetitive[i]
		technical_eff[i] = (delta_bar - 1) * STEP_SIZE
		real_GDP[i] = sp.weighted_exp(1-rho, shares) * sp.weighted_exp(1/elast, shares) * mu_bar * STEP_SIZE
		# Calculate log-linearized variable updates
		dlogP = -sp.weighted_exp(1/elast, shares) / (1 - sp.weighted_exp(1/elast, shares)) * STEP_SIZE
		dtheta_star = gammastar*(sp.weighted_exp(elast[0]/elast, shares) - 1)/(1 - sp.weighted_exp(1/elast, shares)) * (1-theta_star) * STEP_SIZE
		dlogM = shares[0]*dtheta_star/(1-theta_star) + sp.weighted_exp((1-elast)*rho, shares)*dlogP
		dlogshares = (elast-1)*rho*dlogP - dtheta_star/(1-theta_star) + dlogM
		dlogp = (1-rho)*dlogP
		# Update variables
		p_P_new = np.exp(np.log(p_P) + dlogp - dlogP)
		shares_new = np.exp(np.log(shares) + dlogshares)
		mu_new = mu_fn(p_P_new)
		rho_new = rho_fn(p_P_new)
		delta_new = delta_fn(p_P_new)
		theta_star_new = theta_star + dtheta_star
		# Reshape variables to new cutoff
		#theta_init = np.linspace(theta_star, 1, len(mu))
		theta_new = np.linspace(theta_star_new, 1, len(mu))
		shares_new_revised = interp1d(theta, shares_new)(theta_new)
		shares = shares_new_revised/shares_new_revised.sum() * (1-theta_star_new)
		rho = interp1d(theta, rho_new)(theta_new)
		mu = interp1d(theta, mu_new)(theta_new)
		delta = interp1d(theta, delta_new)(theta_new)
		p_P = interp1d(theta, p_P_new)(theta_new)
		A = interp1d(theta, A)(theta_new)
		elast = mu/(mu - 1)
		delta_bar = sp.weighted_exp(delta, shares)
		mu_bar = 1/sp.weighted_exp(1/mu, shares)
		theta_star = theta_star_new
		theta = theta_new
		gammastar = 1/((1-theta_star) * (-elast[0]/rho[0] * np.diff(np.log(mu))[0]/np.diff(theta)[0] + (elast[0]/rho[0] - 1)*np.diff(np.log(A))[0]/np.diff(theta)[0]))
		sales_dist[i,:] = shares/shares.sum()
		markup_dist[i,:] = mu
	return dlogL_range,technical_eff,allocative_eff,darwinian,selection,procompetitive,real_GDP,sales_dist,markup_dist

def nonlinear_results_at_value(mu_bar, effselection, delta_bar, theta_star, dlogL_value):
	dlogL_range,technical_eff,allocative_eff,darwinian,selection,procompetitive,real_GDP,sales_dist,markup_dist = nonlinear_results(mu_bar, effselection, delta_bar, theta_star)
	mu_bar_range = np.array([1/sp.weighted_exp(1/markup_dist[i,:], sales_dist[i,:]) for i in range(len(dlogL_range))])
	welfare = technical_eff + allocative_eff
	res_ind = np.searchsorted(dlogL_range, dlogL_value)
	res_array = np.array([welfare.cumsum()[res_ind], technical_eff.cumsum()[res_ind], allocative_eff.cumsum()[res_ind], darwinian.cumsum()[res_ind], selection.cumsum()[res_ind], procompetitive.cumsum()[res_ind], real_GDP.cumsum()[res_ind], np.log(mu_bar_range[res_ind]/mu_bar_range[0])])
	return res_array/dlogL_value

def plot_nonlinear_results(mu_bar, effselection, delta_bar, theta_star, saveprefix=None):
	dlogL_range,technical_eff,allocative_eff,darwinian,selection,procompetitive,real_GDP,sales_dist,markup_dist = nonlinear_results(mu_bar, effselection, delta_bar, theta_star)
	plt.figure()
	plt.plot(dlogL_range, (technical_eff + allocative_eff).cumsum(), label='Welfare')
	plt.plot(dlogL_range, technical_eff.cumsum(), label='Technical efficiency')
	plt.plot(dlogL_range, allocative_eff.cumsum(), label='Allocative efficiency')
	plt.legend()
	plt.tight_layout()
	plt.xlim([dlogL_range.min(), dlogL_range.max()])
	plt.ylim([0, (technical_eff + allocative_eff).cumsum().max()])
	if saveprefix is not None:
		plt.gcf().savefig(saveprefix + 'nonlinear_welfare.pdf', dpi=300, bbox_inches='tight')
	plt.figure()
	plt.plot(dlogL_range, darwinian.cumsum(), label='Darwinian effect')
	plt.plot(dlogL_range, selection.cumsum(), label='Selection effect')
	plt.plot(dlogL_range, procompetitive.cumsum(), label='Pro-competitive effect')
	plt.plot(dlogL_range, allocative_eff.cumsum(), label='Allocative efficiency')
	plt.legend()
	plt.tight_layout()
	plt.xlim([dlogL_range.min(), dlogL_range.max()])
	if saveprefix is not None:
		plt.gcf().savefig(saveprefix + 'nonlinear_allocativeeff.pdf', dpi=300, bbox_inches='tight')
	gini_plot_values = [0, 0.02, 0.04, 0.06]
	fig,axs = plt.subplots(1, len(gini_plot_values), figsize=(15, 4))
	for i in range(len(gini_plot_values)):
		res_ind = np.searchsorted(dlogL_range, gini_plot_values[i])
		x_arr = np.linspace(0, 1, len(sales_dist[res_ind,:]))
		lorenz = np.cumsum(sales_dist[res_ind,:]/sales_dist[res_ind,:].sum())
		gini = 1 - 2*lorenz.sum()/len(lorenz) 
		axs[i].plot(x_arr, sales_dist[res_ind,:].cumsum())
		axs[i].plot(x_arr, x_arr, color='red', ls='-.')
		axs[i].set_title('$\\Delta \\log L = ' + str(gini_plot_values[i]) + '$, Gini$= ' + str(round(gini, 2)) + '$')
		axs[i].set_xlim([0, 1])
		axs[i].set_ylim([0, 1])
	plt.tight_layout()
	if saveprefix is not None:
		plt.gcf().savefig(saveprefix + 'nonlinear_gini.pdf', dpi=300, bbox_inches='tight')
	fig,axs = plt.subplots(1, len(gini_plot_values), figsize=(15, 4))
	for i in range(len(gini_plot_values)):
		res_ind = np.searchsorted(dlogL_range, gini_plot_values[i])
		x_arr = np.linspace(0, 1, len(sales_dist[res_ind,:]))
		emp_dist = sales_dist[res_ind,:]/markup_dist[res_ind,:]
		emp_dist = emp_dist/emp_dist.sum()
		emp_dist = np.sort(emp_dist)
		lorenz = np.cumsum(emp_dist/emp_dist.sum())
		gini = 1 - 2*lorenz.sum()/len(lorenz) 
		axs[i].plot(x_arr, emp_dist.cumsum())
		axs[i].plot(x_arr, x_arr, color='red', ls='-.')
		axs[i].set_title('$\\Delta \\log L = ' + str(gini_plot_values[i]) + '$, Gini$= ' + str(round(gini, 2)) + '$')
		axs[i].set_xlim([0, 1])
		axs[i].set_ylim([0, 1])
	plt.tight_layout()
	if saveprefix is not None:
		plt.gcf().savefig(saveprefix + 'nonlinear_gini_employment.pdf', dpi=300, bbox_inches='tight')
	log_TFPR_dispersion = np.array([sp.weighted_exp(np.log(markup_dist[i,:])**2, sales_dist[i,:]) - (sp.weighted_exp(np.log(markup_dist[i,:]), sales_dist[i,:]))**2 for i in range(len(dlogL_range))])
	#log_TFPR_dispersion = np.array([sp.weighted_exp(np.log(markup_dist[i,:])**2, sales_dist[0,:]) - (sp.weighted_exp(np.log(markup_dist[i,:]), sales_dist[0,:]))**2 for i in range(len(dlogL_range))])

def frontier_distance(mu_bar, effselection, delta_bar, theta_star):
	dlogY_homog = frontier_distance_homogeneous(mu_bar, effselection, delta_bar, theta_star)
	rho,shares,mu,A,delta = sp.generate_all_variables(mu_bar, effselection=effselection, delta_bar=delta_bar)
	shares = shares/shares.sum() * (1-theta_star)
	delta_bar = sp.weighted_exp(delta, shares)
	elast = mu/(mu - 1)
	theta = np.linspace(theta_star, 1, len(mu))
	p = mu/A
	p_P = p
	mu_fn = interp1d(p, mu, fill_value=(mu[-1], mu[0]), bounds_error=False)
	elast_fn = lambda x: mu_fn(x)/(mu_fn(x) - 1)
	delta_fn = interp1d(p, delta, fill_value=(delta[-1], delta[0]), bounds_error=False)
	# Now we want to implement first-best using taxes tau = 1/mu and markups mu=delta
	delta_curr = delta.copy()
	shares_curr = shares.copy()
	elast_curr = elast.copy()
	tau_curr = np.ones(len(mu))
	mu_curr = mu.copy()
	p_curr = p.copy()
	p_P_curr = p_P.copy()
	Y_curr = 1 
	Lambda_L_curr = sp.weighted_exp(1/tau_curr, shares)
	theta_star_curr = theta_star 
	# Iterate over small shocks
	N_STEPS = 1000
	MIN_DIVISION = 10
	dlogY_steps = np.zeros(N_STEPS)
	for iter_ind in range(N_STEPS):
		REMAINING_STEPS = N_STEPS - iter_ind + MIN_DIVISION
		dlogmu = (1 / REMAINING_STEPS) * (np.log(delta_curr) - np.log(mu_curr))
		dlogtau = (1 / REMAINING_STEPS) * (np.log(1/mu_curr) - np.log(tau_curr))
		dlogp = dlogmu + dlogtau 
		profitability_fn = np.log((1-1/mu_curr)*shares_curr / tau_curr)
		profitability_hazard = np.diff(profitability_fn)[0] / np.diff(theta)[0] * (1 - theta_star)
		gammastar = 1/profitability_hazard
		# Create matrix to solve for (0) dlogLambda_L, (1) dlogM, (2) dlogY, (3) dtheta_star, (4) dlogP
		LHS_mat = np.zeros((5,5))
		RHS_mat = np.zeros((5,5))
		RHS_const_mat = np.zeros((5,1))
		# dlogLambda_L
		LHS_mat[0,0] = 1
		RHS_mat[0,1] = 1
		RHS_mat[0,3] = -shares_curr[0]/(tau_curr[0] * Lambda_L_curr)
		RHS_mat[0,4] = sp.weighted_exp((elast_curr-1)/(tau_curr * Lambda_L_curr), shares_curr)
		RHS_const_mat[0] = sp.weighted_exp((-dlogtau - (elast_curr-1)*dlogp)/(tau_curr * Lambda_L_curr), shares_curr)
		# dlogM
		LHS_mat[1,1] = 1
		RHS_mat[1,3] = shares_curr[0]
		RHS_mat[1,4] = -sp.weighted_exp(elast_curr - 1, shares_curr)
		RHS_const_mat[1] = sp.weighted_exp((elast_curr - 1)*dlogp, shares_curr)
		# dlogY
		LHS_mat[2,2] = 1
		RHS_mat[2,0] = -1
		RHS_mat[2,1] = sp.weighted_exp(delta_curr - 1, shares_curr)
		RHS_mat[2,3] = -shares_curr[0]*(delta_curr[0] - 1)
		RHS_const_mat[2] = -sp.weighted_exp(dlogp, shares_curr)
		# dtheta_star
		LHS_mat[3,3] = 1/gammastar
		RHS_mat[3,0] = 1
		RHS_mat[3,4] = -(elast_curr[0] - 1)
		RHS_const_mat[3] = (elast_curr[0] - 1)*dlogp[0] + dlogtau[0] - 1/(mu_curr[0] - 1)*dlogmu[0]
		# dlogP
		LHS_mat[4,4] = sp.weighted_exp(elast_curr - 1, shares_curr*(1/tau_curr)*(1 - 1/mu_curr))
		RHS_mat[4,0] = 1
		RHS_const_mat[4] = -sp.weighted_exp(-dlogtau - (elast_curr-1)*dlogp + (1/(mu_curr-1))*dlogmu, shares_curr*(1/tau_curr)*(1 - 1/mu_curr))
		# Solve
		dlogLambda_L,dlogM,dlogY,dtheta_star,dlogP = (np.linalg.inv(LHS_mat - RHS_mat) @ RHS_const_mat).ravel()
		dlogY_steps[iter_ind] = dlogY
		# Update aggregates
		theta_star_curr = theta_star_curr + (1-theta_star_curr) * dtheta_star
		Y_curr = np.exp(np.log(Y_curr) + dlogY)
		Lambda_L_curr = np.exp(np.log(Lambda_L_curr) + dlogLambda_L)
		# Update firm-level variables
		mu_curr = np.exp(np.log(mu_curr) + dlogmu)
		tau_curr = np.exp(np.log(tau_curr) + dlogtau)
		p_curr = np.exp(np.log(p_curr) + dlogmu + dlogtau)
		p_P_curr = np.exp(np.log(p_P_curr) + dlogp - dlogP)
		delta_curr = delta_fn(p_P_curr)
		elast_curr = elast_fn(p_P_curr)
		dlogshares = (1-elast_curr)*(dlogp - dlogP) - dtheta_star + dlogM 
		shares_curr = np.exp(np.log(shares_curr) + dlogshares)
		shares_curr = shares_curr/shares_curr.sum()
	return np.log(Y_curr),dlogY_homog,sp.weighted_exp(delta_curr, shares_curr)

def frontier_distance_homogeneous(mu_bar, effselection, delta_bar, theta_star):
	rho,shares,mu,A,delta = sp.generate_all_variables(mu_bar, effselection=effselection, delta_bar=delta_bar)
	delta_bar = sp.weighted_exp(delta, shares)
	elast = mu/(mu - 1)
	theta = np.linspace(theta_star, 1, len(mu))
	p = mu/A
	p_P = p
	# Now we want to implement first-best using taxes tau = 1/mu and markups mu=delta
	delta_curr = np.array([delta_bar])
	shares_curr = np.array([1.0])
	mu_curr = np.array([mu_bar])
	elast_curr = mu_curr/(mu_curr - 1)
	tau_curr = np.ones(len(mu_curr))
	p_curr = mu_curr.copy()
	p_P_curr = p_curr.copy()
	Y_curr = 1 
	Lambda_L_curr = sp.weighted_exp(1/tau_curr, shares)
	theta_star_curr = theta_star 
	#
	rho_avg = sp.weighted_exp(rho, shares)
	mu_fn = lambda x: np.exp(np.log(mu_bar) + (1 - 1/rho_avg)*(np.log(x) - np.log(mu_bar)))
	elast_fn = lambda x: mu_fn(x)/(mu_fn(x) - 1)
	delta_fn = lambda x: delta_bar 
	# Iterate over small shocks
	N_STEPS = 1000
	dlogY_steps = np.zeros(N_STEPS)
	for iter_ind in range(N_STEPS):
		REMAINING_STEPS = N_STEPS - iter_ind
		dlogmu = (1 / REMAINING_STEPS) * (np.log(delta_curr) - np.log(mu_curr))
		dlogtau = (1 / REMAINING_STEPS) * (np.log(1/mu_curr) - np.log(tau_curr))
		dlogp = dlogmu + dlogtau 
		#profitability_fn = np.log((1-1/mu_curr)*shares_curr / tau_curr)
		#profitability_hazard = np.diff(profitability_fn)[0] / np.diff(theta)[0] * (1 - theta_star)
		#gammastar = 1/profitability_hazard
		# Create matrix to solve for (0) dlogLambda_L, (1) dlogM, (2) dlogY, (3) dtheta_star, (4) dlogP
		LHS_mat = np.zeros((5,5))
		RHS_mat = np.zeros((5,5))
		RHS_const_mat = np.zeros((5,1))
		# dlogLambda_L
		LHS_mat[0,0] = 1
		RHS_mat[0,1] = 1
		RHS_mat[0,3] = 0 
		RHS_mat[0,4] = sp.weighted_exp((elast_curr-1)/(tau_curr * Lambda_L_curr), shares_curr)
		RHS_const_mat[0] = sp.weighted_exp((-dlogtau - (elast_curr-1)*dlogp)/(tau_curr * Lambda_L_curr), shares_curr)
		# dlogM
		LHS_mat[1,1] = 1
		RHS_mat[1,3] = 0 
		RHS_mat[1,4] = -sp.weighted_exp(elast_curr - 1, shares_curr)
		RHS_const_mat[1] = sp.weighted_exp((elast_curr - 1)*dlogp, shares_curr)
		# dlogY
		LHS_mat[2,2] = 1
		RHS_mat[2,0] = -1
		RHS_mat[2,1] = sp.weighted_exp(delta_curr - 1, shares_curr)
		RHS_mat[2,3] = 0 
		RHS_const_mat[2] = -sp.weighted_exp(dlogp, shares_curr)
		# dtheta_star
		LHS_mat[3,3] = 1 #1/gammastar
		RHS_mat[3,0] = 1
		RHS_mat[3,4] = -(elast_curr[0] - 1)
		RHS_const_mat[3] = 0 
		# dlogP
		LHS_mat[4,4] = sp.weighted_exp(elast_curr - 1, shares_curr*(1/tau_curr)*(1 - 1/mu_curr))
		RHS_mat[4,0] = 1
		RHS_const_mat[4] = -sp.weighted_exp(-dlogtau - (elast_curr-1)*dlogp + (1/(mu_curr-1))*dlogmu, shares_curr*(1/tau_curr)*(1 - 1/mu_curr))
		# Solve
		dlogLambda_L,dlogM,dlogY,dtheta_star,dlogP = (np.linalg.inv(LHS_mat - RHS_mat) @ RHS_const_mat).ravel()
		dlogY_steps[iter_ind] = dlogY
		# Update aggregates
		theta_star_curr = theta_star_curr + (1-theta_star_curr) * dtheta_star
		Y_curr = np.exp(np.log(Y_curr) + dlogY)
		Lambda_L_curr = np.exp(np.log(Lambda_L_curr) + dlogLambda_L)
		# Update firm-level variables
		mu_curr = np.exp(np.log(mu_curr) + dlogmu)
		tau_curr = np.exp(np.log(tau_curr) + dlogtau)
		p_curr = np.exp(np.log(p_curr) + dlogmu + dlogtau)
		p_P_curr = np.exp(np.log(p_P_curr) + dlogp - dlogP)
		delta_curr = delta_fn(p_P_curr)
		elast_curr = elast_fn(p_P_curr)
		dlogshares = (1-elast_curr)*(dlogp - dlogP) - dtheta_star + dlogM 
		shares_curr = np.exp(np.log(shares_curr) + dlogshares)
		shares_curr = shares_curr/shares_curr.sum()
	return np.log(Y_curr)



def generate_oligopoly_results(mu_bar, effselection, delta_bar, alpha_range):
	rho,shares,mu,A,delta = sp.generate_all_variables(mu_bar, effselection=effselection, delta_bar=delta_bar)
	delta_bar = sp.weighted_exp(delta, shares)
	elast = mu/(mu - 1)
	res_oligopoly = np.zeros((3, len(alpha_range)))
	for i,alpha in enumerate(alpha_range):
		technical_efficiency = (delta_bar-1)*(1-alpha)
		darwinian = (delta_bar-1)*((1-alpha)**2)*sp.weighted_cov(elast, 1/mu, shares)/(1/mu_bar + alpha*sp.weighted_cov(elast, 1/mu, shares))
		alloc_1 = (delta_bar-1)*(1-alpha)*((1-alpha)*sp.weighted_cov(elast, 1/mu, shares) - alpha/mu_bar) + alpha*sp.weighted_exp(elast - 1, shares)*sp.weighted_exp(1/elast, shares)*sp.weighted_exp(1/(elast-1), shares)
		alloc_2 = sp.weighted_exp(1/elast, shares)*sp.weighted_exp((1-rho)*(1-alpha*(sp.weighted_exp(1-rho, shares) + sp.weighted_exp(elast-1, shares)/(elast-1) - (1-alpha)*(delta_bar-1)/(mu_bar-1)) - (elast-1)*((delta_bar-1)*(1-alpha)**2 + alpha*sp.weighted_exp(rho/(elast-1), shares))), shares)
		alloc_denom = 1 + alpha*((mu_bar-1)*sp.weighted_exp(elast-1, shares) - sp.weighted_exp((1-rho)*(1 + (elast-1)*(mu_bar-1)), shares))
		allocative_efficiency = mu_bar * (alloc_1 + alloc_2)/alloc_denom
		procompetitive = allocative_efficiency - darwinian
		res_oligopoly[:,i] = technical_efficiency,darwinian,procompetitive
	return pd.DataFrame(res_oligopoly, columns=alpha_range)

def tabulate_oligopoly_results(boundary_condition_cols):
	res = []
	alpha_range = np.arange(0, 0.21, 0.05)
	for c in boundary_condition_cols:
		res.append(generate_oligopoly_results(c[0], c[1], c[2], alpha_range))
	return pd.concat(res, ignore_index=True)

def generate_markup_regressions(mu_bar):
	rho,shares,mu,A,delta = sp.generate_all_variables(mu_bar, effselection=True, delta_bar=mu_bar)
	all_vars = pd.DataFrame({'shares' : shares, 'prod' : A, 'mu' : mu, 'rho' : rho, 'price' : mu/A})
	all_vars['y'] = all_vars['shares']/all_vars['price']
	all_vars['emp'] = all_vars['y']/all_vars['prod']
	all_vars['const'] = 1
	dep_vars = ['mu', 'np.log(mu)']
	spec_name = ['mu', 'log(mu)']
	ind_vars = ['np.log(shares)', 'np.log(emp)', 'np.log(prod)']
	weight_vars = ['const', 'shares', 'emp']
	wt_spec_name = ['unwt', 'sales-wt', 'emp-wt']
	all_res = []
	model_names = []
	for vy,ylabel in zip(dep_vars, spec_name):
		for vx in ind_vars:
			for vwt,wtlabel in zip(weight_vars, wt_spec_name):
				all_res.append(smf.wls(vy + ' ~ 1 + ' + vx, data=all_vars, weights=all_vars[vwt]).fit())
				model_names.append(str(len(model_names)+1) + ': ' + ylabel + ' ' + wtlabel)
	print(summary_col(all_res[:int(len(all_res)/2)], model_names=range(len(all_res)), float_format='%0.4f', regressor_order=ind_vars, drop_omitted=True).as_latex())
	print(summary_col(all_res[int(len(all_res)/2):], model_names=range(len(all_res)), float_format='%0.4f', regressor_order=ind_vars, drop_omitted=True).as_latex())

def generate_markup_percentiles(mu_bar):
	rho,shares,mu,A,delta = sp.generate_all_variables(mu_bar, effselection=True, delta_bar=mu_bar)
	theta = np.linspace(0, 1, len(mu))
	sales_cumsum = np.cumsum(shares) / shares.sum()
	pctils = [0.25, 0.5, 0.75, 0.9, 0.95, 0.99]
	print(interp1d(theta, mu)(pctils))
	print(interp1d(sales_cumsum, mu)(pctils))

def HSA_results_with_noise(mu_bar, effselection, delta_bar, theta_star, R2):
	rho,shares,mu,A,delta = sp.generate_all_variables(mu_bar, effselection=effselection, delta_bar=delta_bar)
	elast = mu/(mu - 1)
	theta = np.linspace(0, 1, len(mu))
	SAMPLE_NUM = 1000000
	type_sample = np.random.uniform(size=SAMPLE_NUM)
	mu_sample = interp1d(theta, mu)(type_sample)
	A_sample = interp1d(theta, A)(type_sample)
	shares_sample = interp1d(theta, shares)(type_sample)
	mu_noise = np.random.normal(size=mu_sample.shape)
	stdev_range = np.linspace(0, 0.5, 100)
	rsq_results_salesreg = np.zeros(len(stdev_range))
	rsq_results_costreg = np.zeros(len(stdev_range))
	for i,stdev_errors in enumerate(stdev_range):
		mu_with_noise = stdev_errors*mu_noise + mu_sample 
		MU_MIN = 1.00001
		mu_with_noise[mu_with_noise <= MU_MIN] = MU_MIN
		rsq_results_salesreg[i] = sm.WLS(np.log(mu_with_noise), sm.add_constant(np.log(shares_sample)), weights=shares_sample).fit().rsquared
		rsq_results_costreg[i] = sm.WLS(np.log(mu_with_noise), sm.add_constant(-np.log(A_sample)), weights=shares_sample).fit().rsquared
	stdev_choose_salesreg = interp1d(rsq_results_salesreg, stdev_range)(0.16)
	stdev_choose_costreg = interp1d(rsq_results_costreg, stdev_range)(0.50)
	mu_with_noise = stdev_choose_salesreg*mu_noise + mu_sample 
	MU_MIN = 1.01
	mu_with_noise[mu_with_noise <= MU_MIN] = MU_MIN
	elast_with_noise = mu_with_noise/(mu_with_noise - 1)
	mu_bar = 1/sp.weighted_exp(1/mu_sample, shares_sample)
	xi_epsilon = sp.weighted_cov(elast_with_noise, 1/mu_with_noise, shares_sample)
	print(mu_bar*(1.045-1)*xi_epsilon)
	print(mu_bar*(1.09-1)*xi_epsilon)
	mu_with_noise = stdev_choose_costreg*mu_noise + mu_sample 
	MU_MIN = 1.01
	mu_with_noise[mu_with_noise <= MU_MIN] = MU_MIN
	elast_with_noise = mu_with_noise/(mu_with_noise - 1)
	mu_bar = 1/sp.weighted_exp(1/mu_sample, shares_sample)
	xi_epsilon = sp.weighted_cov(elast_with_noise, 1/mu_with_noise, shares_sample)
	print(mu_bar*(1.045-1)*xi_epsilon)
	print(mu_bar*(1.09-1)*xi_epsilon)


def export_calibration_tables(mu_bar_list):
	writer = pd.ExcelWriter('output/calibration_outputs.xlsx', engine='xlsxwriter')
	for mu_bar in mu_bar_list:
		rho,shares,mu,A,delta_effselection = sp.generate_all_variables(mu_bar, effselection=True, delta_bar=mu_bar)
		p = mu/A
		y = shares/p 
		_,_,_,_,delta_effentry = sp.generate_all_variables(mu_bar, effselection=False, delta_bar=mu_bar)
		_,_,_,_,delta_1 = sp.generate_all_variables_deltacutoff(mu_bar, delta_cutoff=1)
		all_dat = pd.DataFrame({
			'rho' : rho,
			'lambda' : shares,
			'mu' : mu,
			'AB' : A,
			'p' : p,
			'y' : y,
			'delta_effselection' : delta_effselection,
			'delta_effentry' : delta_effentry,
			'delta_cutoff1' : delta_1,
			'Ups_effselection' : (delta_effselection*shares)/(delta_effselection*shares).sum() * len(shares),
			'Ups_effentry' : (delta_effentry*shares)/(delta_effentry*shares).sum() * len(shares),
			'Ups_cutoff1' : (delta_1*shares)/(delta_1*shares).sum() * len(shares)
		})
		all_dat.to_excel(writer, sheet_name=str(mu_bar), index=False)
	writer.save()

def tabulate_all_results():
	columns = [[1.045, True, 1.045, 0.15], [1.045, False, 1.045, 0.15], [1.09, True, 1.09, 0.15], [1.09, False, 1.09, 0.15]]
	description = ['effselection_1045', 'effentry_1045', 'effselection_109', 'effentry_109']
	Table1 = np.zeros((8, len(columns)))
	Table2 = np.zeros((5, len(columns)))
	Table3 = np.zeros((8, len(columns)))
	Table4 = np.zeros((5, len(columns)))
	Table8 = np.zeros((8, len(columns)))
	Table11 = np.zeros((3, len(columns)))
	Table12 = np.zeros((7, len(columns)))
	Table13 = np.zeros((4, len(columns)))
	Table15 = np.zeros((7, 3))
	for i,c in enumerate(columns):
		Table1[:,i],Table2[:,i],Table4[:,i] = generate_HSA_results(c[0], c[1], c[2], c[3])
		Table8[:,i],_,_ = generate_HSA_results(c[0], c[1], c[2], c[3], product=True)
		Table3[:,i] = nonlinear_results_at_value(c[0], c[1], c[2], c[3], 0.5)
		Table11[:,i] = frontier_distance(c[0], c[1], c[2], c[3])
		Table12[:,i],Table13[:,i] = generate_Kimball_results(c[0], c[1], c[2], c[3])
		if i==2:
			plot_nonlinear_results(c[0], c[1], c[2], c[3], saveprefix='../Draft/output/')
		if i>=2:
			plot_all_variables(c[0], c[1], c[2], c[3], saveprefix='../Draft/output/calibration_fit_' + description[i] + '_')

	print('Table 1:')
	print(pd.DataFrame(Table1).to_latex(index=False, float_format="%.3f"))
	print('Table 2:')
	print(pd.DataFrame(Table2).to_latex(index=False, float_format="%.3f"))
	print('Table 3:')
	print(pd.DataFrame(Table3).to_latex(index=False, float_format="%.3f"))
	print('Table 4:')
	print(pd.DataFrame(Table4).to_latex(index=False, float_format="%.3f"))
	print('How important is selection?')
	print(pd.DataFrame(np.array([
		generate_HSA_results_cutoff(1.045, 1, 0.15), 
		generate_HSA_results_cutoff(1.09, 1, 0.15)]).T).to_latex(index=False, float_format="%.3f"))

	print('Table 8:')
	print(pd.DataFrame(Table8).to_latex(index=False, float_format="%.3f"))
	# Run for Tables 9-10
	boundary_condition_robustness()
	print('Table 11:')
	print(pd.DataFrame(Table11[:-1,:]).to_latex(index=False, float_format="%.3f"))
	print('Table 12:')
	print(pd.DataFrame(Table12).to_latex(index=False, float_format="%.3f"))
	print('Table 13:')
	print(pd.DataFrame(Table13).to_latex(index=False, float_format="%.3f"))
	oligopoly_cols = [columns[1], columns[3]]
	print('Table 14:')
	print(tabulate_oligopoly_results(oligopoly_cols).to_latex(index=False, float_format="%.3f"))
	print('Table 15:')
	Table15[:,0] = Table12[:,2]
	Table15[:,1] = Table12[:,3]
	Table15[:,2] = klenow_willis_results(0.15, plot=True, saveprefix='../Draft/output/klenow_willis_')
	print(pd.DataFrame(Table15).to_latex(index=False, float_format="%.3f"))

	#export_calibration_tables([1.05, 1.06, 1.07, 1.08, 1.09, 1.10, 1.11, 1.12, 1.13, 1.14, 1.15,  1.16, 1.17, 1.18, 1.19, 1.20])


tabulate_all_results()
plt.show()



