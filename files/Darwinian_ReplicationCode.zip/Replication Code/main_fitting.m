%% Estimation on Kimball Aggregator
% Program by Sihwan Yang(PhD student in UCLA) on Feb 24, 2020
% 'col' controls solution options of delta and mu
% col == 1 (mu_bar = 1.045, delta_bar = delta0)
%     == 2 (mu_bar = 1.045, delta_bar = 1.045) 
%     == 3 (mu_bar = 1.090, delta_bar = delta0)
%     == 4 (mu_bar = 1.090, delta_bar = 1.090)

% product_model == 0(original lambda)
%               == 1(use lambda as lambda/product_curve)

clear
clc
close all

axoptions={'scaled ticks = false',...
'y tick label style={/pgf/number format/.cd, fixed, fixed zerofill,precision=2, set thousands separator={}}',...
'x tick label style={/pgf/number format/.cd, precision=2, set thousands separator={}}',...
'legend style={font=\scriptsize}'};


Table1 = [];
Table2 = [];
A_stack = [];
y_stack = [];
Ups_stack = [];
mu_stack = [];
rho_stack = [];
delta_stack = [];
lambda_stack = [];
A_pi_stack = [];
S1_pi_stack = [];
S2_pi_stack = [];
S3_pi_stack = [];

for col = 1:4
%% Customize Folder directory
addpath('./SLMtools')
addpath('./Data')
addpath('./Functions')

% addpath('/Users/sihwan/Documents/MATLAB/Baqaee_RA/SLMtools')
% cd('C:\Users\Baqaee\Dropbox\Work\Entry with Kimball Preferences\Fitting')
% folder = 'C:\Users\Baqaee\Dropbox\Work\Entry with Kimball Preferences\Draft\';
product_model = 0;
theta_star = 0.15; 
%% Data import and Exogenous input 
data_PRODCOM = xlsread('DataFigA2.xlsx','Sheet1');
data_VAT = xlsread('DataFigA2.xlsx','Sheet2');
options = optimset('Display','iter','MaxFunEvals',10000);

theta_new = [data_VAT(:,4) ; 1]; % VAT Manufacturing input
lambda_new = [data_VAT(:,3) ; 1]; % VAT Manufacturing input
theta_new_0 = [0 ; data_VAT(:,4)];
lambda_new_0 = [0 ; data_VAT(:,3)];

lambda_50 = [0.13926788 ; data_PRODCOM(:,4)];
lambda_50_1 = [0.13926788 ; data_PRODCOM(:,4) ;1]; % PRODCOM input
theta = data_PRODCOM(:,2);
theta_0 = [0 ; data_PRODCOM(:,2)];
theta_50 = [0.62183176 ; data_PRODCOM(:,2)];
theta_50_1 = [0.62183176 ; data_PRODCOM(:,2) ; 1]; % PRODCOM input
rho = data_PRODCOM(:,5); 
rho_1 = [0.97 ; data_PRODCOM(:,5)];
%% options in Table 1
% Column 1: mu_bar = 1.045, delta_bar = delta0;
% Column 2: mu_bar = 1.045, delta_bar = 1.045;
% Column 3: mu_bar = 1.090, delta_bar = delta0;
% Column 4: mu_bar = 1.090, delta_bar = 1.090;
if col == 1
    mu_bar = 1.045;
    delta_bar(col) = NaN;
elseif col == 2
    mu_bar = 1.045;
    delta_bar(col) = 1.045;
elseif col == 3
    mu_bar = 1.09;
    delta_bar(col) = NaN;
elseif col == 4
    mu_bar = 1.09;
    delta_bar(col) = mu_bar;
end

M = 1; % Number of firms normalized to 1
%% smoothing : truncated Beta distribution (PRODCOM)
% https://www.mathworks.com/matlabcentral/fileexchange/24443-slm-shape-language-modeling
h = 0.0001; % grid size
n = 1/h; % number of grid
pstep = 10; % grid stepsize to draw graphs
theta_grid = theta_new(1):h:1;
theta_grid_all = 0:h:1;
firstobs = floor(n*theta_grid(1))+1;

data_PRODCOM_input = [theta_50_1, lambda_50_1];
F = @(x,data) x(1)*ones(length(data),1)+x(2)*data(:,1)+x(3)*data(:,1).^x(4)-(x(1)+x(2)+x(3));
[x1,resnorm,~,exitflag,output] = lsqcurvefit(F,[0 1 .2 90],data_PRODCOM_input(:,1),log(data_PRODCOM_input(:,2)));
lambda_grid_temp = exp(F(x1,theta_grid_all'));
lambda_grid_PRODCOM = lambda_grid_temp';
slm_rho = slmengine(theta_0,rho_1,'knots',10,'concavedown','on','maxslope',-0.05);
rho_grid = slmeval(theta_grid_all,slm_rho);
%% Differentiate Sales share (PRODCOM)
lambda_diff_PRODCOM = diff(lambda_grid_PRODCOM)/h;
rho_diff_PRODCOM = lambda_grid_PRODCOM(2:end)./lambda_diff_PRODCOM.*diff(rho_grid)/h + rho_grid(2:end);

%% Record rho from PRODCOM and interpolate
theta_VAT = [floor(theta_50(1)*n) ; floor((theta_50(1)+theta_50(2))/2*n) ; ...,
    floor(theta_50(2:end)*n)];
rho_diff_VAT = [0.97*ones(8,1) ; rho_diff_PRODCOM(theta_VAT)'];
%% Fitting Sales share (VAT Manufacturing)
data_VAT_input = [theta_new , lambda_new];
[x2,resnorm,~,exitflag,output] = lsqcurvefit(F,[0 1 .2 90],data_VAT_input(:,1),log(data_VAT_input(:,2)));
lambda_grid_all_temp = exp(F(x2,theta_grid'));
lambda_grid_all = lambda_grid_all_temp';
slm_rho2 = slmengine(theta_new_0,rho_diff_VAT,'knots',10,'concavedown','on','maxslope',-0.05);
rho_diff_all = slmeval(theta_grid_all,slm_rho2);
rho_diff = rho_diff_all(2:end);

%% Fitting Product Curve 
products = [
1   
1
1
1
1.36
2.0550459
2.200495
2.4203297
2.4203895
2.3727506
3.294686
3.225
3.3308824
3.6511628
5.2162162
4.1724138
8.3095238
8.8780488
];

products_slm = slmengine(data_VAT_input(:,1),products,'knots',10,'concaveup','on');
products_curve = slmeval(theta_grid,products_slm);
%% Differentiate Sales share (VAT Manufacturing)
% dlog(lambda)/d(theta)=constant from 0 to 0.16
lambda_diff = diff(lambda_grid_all)/h;

if product_model == 1
    lambda_diff_norm_product = lambda_diff./products_curve(2:end);
    lambda_diff = lambda_diff_norm_product;
    lambda_agg_product = 0;
    for i=1:n-firstobs-1
        y0 = lambda_diff(i);
        y1 = lambda_diff(i+1);
        lambda_agg_product = lambda_agg_product + h/2*(y0+y1);
    end
    lambda_diff = lambda_diff_norm_product/lambda_agg_product;    
end

lambda_diff2 = 1/h*diff(lambda_diff)./lambda_diff(2:end);
lambda_diff2_all = [lambda_diff2(1)*ones(1,firstobs+1), lambda_diff2];
lambda_cumul1 = ones(1,firstobs+1);
lambda_cumul2 = zeros(1,firstobs+1);
for i=1:firstobs
    y0 = lambda_diff2_all(i);
    y1 = lambda_diff2_all(i+1);
    lambda_cumul1(i+1) = lambda_cumul1(i) * exp(h/2*(y0+y1));
end
lambda_diff_temp = lambda_cumul1/(lambda_cumul1(end)/lambda_diff(1));
for i=1:firstobs
    y0 = lambda_diff_temp(i);
    y1 = lambda_diff_temp(i+1);
    lambda_cumul2(i+1) = lambda_cumul2(i) + h/2*(y0+y1);
end
lambda_cumul_temp = lambda_cumul2/(lambda_cumul2(end)/lambda_grid_all(1));
lambda_diff_norm = [lambda_diff_temp, lambda_diff(2:end)];
lambda_cumul_norm = [lambda_cumul_temp(2:end), lambda_grid_all(2:end)];
lambda_diff = lambda_diff_norm;
lambda_temp = 1/h*diff(lambda_diff)./lambda_diff(2:end); 


%% Solving ODE on markup(mu) : Runge-Kunta Method of order 4
mu0 = 1.2;
func = @(x) mseodemubars2(x,mu_bar,lambda_diff,rho_diff,n,h);
mu0_opt = fminsearch(func,mu0,options); % Find initial value that matched moment
rho_temp = (ones(1,n)-rho_diff)./rho_diff; 
mu = zeros(1,n-1); % n-1 * 1 vector
mu(1) = mu0_opt;
for i=1:n-2
    a1 = lambda_temp(i);
    a2 = (lambda_temp(i)+lambda_temp(i+1))/2;
    a3 = lambda_temp(i+1);
    b1 = rho_temp(i+1);
    b2 = (rho_temp(i+1)+rho_temp(i+2))/2;
    b3 = rho_temp(i+2);
    mu(i+1) = rk4step(mu(i),h,a1,a2,a3,b1,b2,b3,@ydot1);
end
%% Solving ODE on productivity(Aa) : Runge-Kunta Method of order 4
mu_temp = (mu-ones(1,n-1))./rho_diff(2:end); 
Aa = zeros(1,n-1);
Aa(1) = 1; % initial value of productivity is 1 for type-0 firm
for i=1:n-2
    a1 = lambda_temp(i);
    a2 = (lambda_temp(i)+lambda_temp(i+1))/2;
    a3 = lambda_temp(i+1);
    b1 = mu_temp(i);
    b2 = (mu_temp(i)+mu_temp(i+1))/2;
    b3 = mu_temp(i+1);
    Aa(i+1) = rk4step(Aa(i),h,a1,a2,a3,b1,b2,b3,@ydot2);
end
%% define inverse mapping from quantities to type
ytheta = lambda_diff(2:end).*Aa./(mu*M*(1-theta_star));
%% Solving ODE on infra-marginal consumption surplus ratios(delta)
delta0 = 0.9;
if or(col==1,col==3)
    func2 = @(x) mseodedeltabars3(x,mu,lambda_diff,n,h);
    delta0_opt = fminsearch(func2,delta0,options); % initial value that matched first delta
elseif or(col==2,col==4)
    func2 = @(x) mseodedeltabars2(x,delta_bar(col),mu,lambda_diff,n,h);
    delta0_opt = fminsearch(func2,delta0,options); % initial value that matched moment    
end

mu_hat = mu;
delta = zeros(1,n-1); 

delta(1) = delta0_opt;
for i=1:n-2
    a1 = lambda_temp(i);
    a2 = (lambda_temp(i)+lambda_temp(i+1))/2;
    a3 = lambda_temp(i+1);
    b1 = mu_hat(i);
    b2 = (mu_hat(i)+mu_hat(i+1))/2;
    b3 = mu_hat(i+1);
    delta(i+1) = rk4step(delta(i),h,a1,a2,a3,b1,b2,b3,@ydot3);
end

%% Solving for Kimball Aggregator(Y)
% aggregate output Y normalized to 1
Y = delta.*lambda_diff(2:end)/(intweight3(delta,lambda_diff,n,h)*(1-theta_star));

%% Demand Curve
expdelta = intweight3(delta,lambda_diff,n,h); % Exp_lambda(delta)
if or(col==1,col==3)
   delta_bar(col) = expdelta;
end
demand = expdelta*diff(Y)/h.*(diff(ytheta)/h).^(-1); 

%% confirmation
lambda_agg = 0;
for i=1:n-1
    y0 = lambda_diff(i);
    y1 = lambda_diff(i+1);
    lambda_agg = lambda_agg + h/2*(y0+y1);
end
 
A_stack = [A_stack, Aa'];
y_stack = [y_stack, ytheta'];
Ups_stack = [Ups_stack, Y'];
mu_stack = [mu_stack, mu'];
rho_stack = [rho_stack, rho_diff'];
delta_stack = [delta_stack, delta'];
lambda_stack = [lambda_stack, lambda_diff'];

end

% filename = 'Prod_Ups_ODE.xlsx';
% writematrix(A_stack,filename,'Sheet','A');
% writematrix(y_stack,filename,'Sheet','y');
% writematrix(Ups_stack,filename,'Sheet','Ups');
% writematrix(mu_stack,filename,'Sheet','mu');
% writematrix(rho_stack,filename,'Sheet','rho');
% writematrix(delta_stack,filename,'Sheet','delta');
% writematrix(lambda_stack,filename,'Sheet','lambda');

